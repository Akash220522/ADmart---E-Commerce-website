"use client";

import { useState, Suspense } from "react";
import { useSearchParams } from "next/navigation";
import Link from "next/link";
import { Header } from "@/components/layout/header";
import { Footer } from "@/components/layout/footer";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Package,
  Truck,
  CheckCircle,
  MapPin,
  Clock,
  Box,
  ArrowRight,
  Search,
  Phone,
} from "lucide-react";

const trackingSteps = [
  {
    status: "ordered",
    label: "Order Placed",
    description: "Your order has been placed successfully",
    date: "Jan 25, 2026 - 10:30 AM",
    completed: true,
  },
  {
    status: "confirmed",
    label: "Order Confirmed",
    description: "Seller has confirmed your order",
    date: "Jan 25, 2026 - 11:45 AM",
    completed: true,
  },
  {
    status: "packed",
    label: "Packed",
    description: "Your item has been packed and ready for dispatch",
    date: "Jan 26, 2026 - 02:15 PM",
    completed: true,
  },
  {
    status: "shipped",
    label: "Shipped",
    description: "Your package is on the way",
    date: "Jan 27, 2026 - 09:00 AM",
    completed: true,
  },
  {
    status: "out_for_delivery",
    label: "Out for Delivery",
    description: "Your package is out for delivery",
    date: "Expected: Jan 28, 2026",
    completed: false,
  },
  {
    status: "delivered",
    label: "Delivered",
    description: "Package will be delivered to your doorstep",
    date: "Expected: Jan 28, 2026",
    completed: false,
  },
];

const statusIcons = {
  ordered: Package,
  confirmed: CheckCircle,
  packed: Box,
  shipped: Truck,
  out_for_delivery: MapPin,
  delivered: CheckCircle,
};

function TrackOrderContent() {
  const searchParams = useSearchParams();
  const orderId = searchParams.get("id") || "";
  const [trackingId, setTrackingId] = useState(orderId);
  const [isTracking, setIsTracking] = useState(!!orderId);

  const handleTrack = () => {
    if (trackingId.trim()) {
      setIsTracking(true);
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <Header />
      <main className="container mx-auto px-4 py-8">
        <h1 className="text-3xl font-bold mb-8">Track Your Order</h1>

        {/* Search Box */}
        <div className="glass-bubble rounded-2xl p-6 mb-8">
          <div className="flex flex-col md:flex-row gap-4">
            <div className="flex-1 relative">
              <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
              <Input
                value={trackingId}
                onChange={(e) => setTrackingId(e.target.value)}
                placeholder="Enter Order ID or Tracking Number"
                className="pl-12 h-12 bg-secondary/50"
              />
            </div>
            <Button onClick={handleTrack} className="h-12 px-8 bg-primary hover:bg-primary/90 gap-2">
              Track Order
              <ArrowRight className="w-4 h-4" />
            </Button>
          </div>
        </div>

        {isTracking && (
          <div className="grid lg:grid-cols-3 gap-8">
            {/* Tracking Timeline */}
            <div className="lg:col-span-2">
              <div className="glass-bubble rounded-2xl p-8">
                <div className="flex items-center justify-between mb-8">
                  <div>
                    <h2 className="text-xl font-semibold">Order Status</h2>
                    <p className="text-muted-foreground">Order ID: {trackingId || "ADM1706234567"}</p>
                  </div>
                  <div className="text-right">
                    <p className="text-sm text-muted-foreground">Estimated Delivery</p>
                    <p className="font-semibold text-primary">Jan 28, 2026</p>
                  </div>
                </div>

                <div className="relative">
                  {trackingSteps.map((step, index) => {
                    const Icon = statusIcons[step.status as keyof typeof statusIcons];
                    const isLast = index === trackingSteps.length - 1;

                    return (
                      <div key={step.status} className="flex gap-4 pb-8 relative">
                        {/* Vertical Line */}
                        {!isLast && (
                          <div
                            className={`absolute left-6 top-12 w-0.5 h-full -translate-x-1/2 ${
                              step.completed ? "bg-primary" : "bg-border"
                            }`}
                          />
                        )}

                        {/* Icon */}
                        <div
                          className={`relative z-10 w-12 h-12 rounded-full flex items-center justify-center flex-shrink-0 transition-all ${
                            step.completed
                              ? "bg-primary text-primary-foreground glow-purple"
                              : "bg-secondary text-muted-foreground"
                          }`}
                        >
                          <Icon className="w-5 h-5" />
                        </div>

                        {/* Content */}
                        <div className="flex-1 pt-1">
                          <div className="flex items-start justify-between">
                            <div>
                              <h3 className={`font-semibold ${step.completed ? "text-foreground" : "text-muted-foreground"}`}>
                                {step.label}
                              </h3>
                              <p className="text-sm text-muted-foreground mt-1">{step.description}</p>
                            </div>
                            <p className={`text-sm ${step.completed ? "text-primary" : "text-muted-foreground"}`}>
                              {step.date}
                            </p>
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            </div>

            {/* Delivery Info */}
            <div className="space-y-6">
              {/* Delivery Address */}
              <div className="glass-bubble rounded-2xl p-6">
                <h3 className="font-semibold mb-4 flex items-center gap-2">
                  <MapPin className="w-5 h-5 text-primary" />
                  Delivery Address
                </h3>
                <div className="text-sm">
                  <p className="font-medium">John Doe</p>
                  <p className="text-muted-foreground mt-1">
                    123, ABC Apartments, MG Road<br />
                    Bangalore, Karnataka - 560001
                  </p>
                  <p className="text-muted-foreground mt-2">
                    Phone: +91 9876543210
                  </p>
                </div>
              </div>

              {/* Courier Info */}
              <div className="glass-bubble rounded-2xl p-6">
                <h3 className="font-semibold mb-4 flex items-center gap-2">
                  <Truck className="w-5 h-5 text-primary" />
                  Courier Details
                </h3>
                <div className="text-sm">
                  <p className="font-medium">BlueDart Express</p>
                  <p className="text-muted-foreground mt-1">
                    AWB: BD123456789IN
                  </p>
                  <Button variant="outline" size="sm" className="mt-4 w-full gap-2 bg-transparent">
                    <Phone className="w-4 h-4" />
                    Contact Courier
                  </Button>
                </div>
              </div>

              {/* Delivery Agent */}
              <div className="glass-bubble rounded-2xl p-6">
                <h3 className="font-semibold mb-4 flex items-center gap-2">
                  <Clock className="w-5 h-5 text-primary" />
                  Expected Timeline
                </h3>
                <div className="space-y-3 text-sm">
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Order Date</span>
                    <span>Jan 25, 2026</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Dispatch Date</span>
                    <span>Jan 27, 2026</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Delivery Date</span>
                    <span className="text-primary font-semibold">Jan 28, 2026</span>
                  </div>
                </div>
              </div>

              {/* Need Help */}
              <div className="glass-card rounded-2xl p-6 text-center">
                <h3 className="font-semibold mb-2">Need Help?</h3>
                <p className="text-sm text-muted-foreground mb-4">
                  Having issues with your delivery?
                </p>
                <Link href="/support">
                  <Button variant="outline" className="w-full bg-transparent">Contact Support</Button>
                </Link>
              </div>
            </div>
          </div>
        )}

        {!isTracking && (
          <div className="glass-bubble rounded-3xl p-12 text-center max-w-lg mx-auto">
            <Truck className="w-20 h-20 mx-auto mb-6 text-primary bubble-float" />
            <h2 className="text-2xl font-bold mb-4">Track Your Package</h2>
            <p className="text-muted-foreground mb-6">
              Enter your order ID or tracking number above to see the current status of your delivery
            </p>
            <div className="flex justify-center gap-4 text-sm text-muted-foreground">
              <div className="flex items-center gap-2">
                <CheckCircle className="w-4 h-4 text-green-500" />
                <span>Real-time updates</span>
              </div>
              <div className="flex items-center gap-2">
                <MapPin className="w-4 h-4 text-primary" />
                <span>Live location</span>
              </div>
            </div>
          </div>
        )}
      </main>
      <Footer />
    </div>
  );
}

export default function TrackOrderPage() {
  return (
    <Suspense fallback={<div className="min-h-screen bg-background" />}>
      <TrackOrderContent />
    </Suspense>
  );
}
