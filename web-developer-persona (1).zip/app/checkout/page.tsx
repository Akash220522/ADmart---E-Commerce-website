"use client";

import { useState } from "react";
import Image from "next/image";
import Link from "next/link";
import { useRouter } from "next/navigation";
import {
  CreditCard,
  Smartphone,
  Banknote,
  MapPin,
  Plus,
  Check,
  ChevronRight,
  Shield,
  Truck,
  ArrowLeft,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Header } from "@/components/layout/header";
import { Footer } from "@/components/layout/footer";
import { useStore, type Address, type Order } from "@/context/store-context";
import { useToast } from "@/hooks/use-toast";
import { cn } from "@/lib/utils";

type PaymentMethod = "cod" | "card" | "upi";

export default function CheckoutPage() {
  const router = useRouter();
  const { cart, cartTotal, user, setUser, clearCart, appliedCoupon, discount } =
    useStore();
  const { toast } = useToast();

  const [step, setStep] = useState<"address" | "payment" | "confirm">("address");
  const [selectedAddress, setSelectedAddress] = useState<Address | null>(
    user?.addresses.find((a) => a.isDefault) || null
  );
  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>("cod");
  const [loading, setLoading] = useState(false);
  const [showAddAddress, setShowAddAddress] = useState(false);
  const [newAddress, setNewAddress] = useState({
    name: user?.name || "",
    phone: user?.phone || "",
    street: "",
    city: "",
    state: "",
    pincode: "",
  });

  // Card details state
  const [cardDetails, setCardDetails] = useState({
    number: "",
    name: "",
    expiry: "",
    cvv: "",
  });

  // UPI state
  const [upiId, setUpiId] = useState("");

  const discountAmount = appliedCoupon ? (cartTotal * discount) / 100 : 0;
  const deliveryCharge = cartTotal > 499 ? 0 : 49;
  const finalTotal = cartTotal - discountAmount + deliveryCharge;

  const handleAddAddress = () => {
    if (
      !newAddress.name ||
      !newAddress.phone ||
      !newAddress.street ||
      !newAddress.city ||
      !newAddress.state ||
      !newAddress.pincode
    ) {
      toast({
        title: "Error",
        description: "Please fill in all address fields.",
        variant: "destructive",
      });
      return;
    }

    const address: Address = {
      id: Date.now().toString(),
      ...newAddress,
      isDefault: !user?.addresses.length,
    };

    if (user) {
      setUser({
        ...user,
        addresses: [...user.addresses, address],
      });
    }

    setSelectedAddress(address);
    setShowAddAddress(false);
    toast({
      title: "Address Added",
      description: "Your address has been saved.",
    });
  };

  const handlePlaceOrder = async () => {
    if (!selectedAddress) {
      toast({
        title: "Error",
        description: "Please select a delivery address.",
        variant: "destructive",
      });
      return;
    }

    setLoading(true);
    await new Promise((resolve) => setTimeout(resolve, 2000));

    const order: Order = {
      id: `ADM${Date.now()}`,
      items: cart,
      total: finalTotal,
      status: "confirmed",
      paymentMethod:
        paymentMethod === "cod"
          ? "Cash on Delivery"
          : paymentMethod === "card"
          ? "Credit/Debit Card"
          : "UPI",
      address: selectedAddress,
      date: new Date().toISOString(),
      trackingId: `TRK${Math.random().toString(36).substring(2, 10).toUpperCase()}`,
    };

    if (user) {
      setUser({
        ...user,
        orders: [...user.orders, order],
      });
    }

    clearCart();
    setLoading(false);

    toast({
      title: "Order Placed Successfully!",
      description: `Your order #${order.id} has been confirmed.`,
    });

    router.push(`/order-success?id=${order.id}`);
  };

  if (cart.length === 0) {
    return (
      <div className="min-h-screen bg-background">
        <Header />
        <div className="max-w-7xl mx-auto px-4 py-20 text-center">
          <h1 className="text-2xl font-bold text-foreground mb-4">
            Your Cart is Empty
          </h1>
          <p className="text-muted-foreground mb-8">
            Add some items to your cart before checkout.
          </p>
          <Link href="/">
            <Button className="bg-primary hover:bg-primary/80 text-primary-foreground">
              Continue Shopping
            </Button>
          </Link>
        </div>
        <Footer />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <Header />
      <main className="max-w-7xl mx-auto px-4 py-8">
        {/* Breadcrumb */}
        <nav className="flex items-center gap-2 text-sm text-muted-foreground mb-8">
          <Link href="/" className="hover:text-primary">
            Home
          </Link>
          <ChevronRight className="w-4 h-4" />
          <Link href="/cart" className="hover:text-primary">
            Cart
          </Link>
          <ChevronRight className="w-4 h-4" />
          <span className="text-foreground">Checkout</span>
        </nav>

        <h1 className="text-2xl md:text-3xl font-bold text-foreground mb-8">
          Checkout
        </h1>

        {/* Progress Steps */}
        <div className="flex items-center justify-center mb-12">
          <div className="flex items-center gap-4">
            <button
              type="button"
              className={cn(
                "flex items-center gap-2 px-4 py-2 rounded-full transition-colors",
                step === "address"
                  ? "bg-primary text-primary-foreground"
                  : "glass text-muted-foreground"
              )}
              onClick={() => setStep("address")}
            >
              <MapPin className="w-4 h-4" />
              <span className="hidden sm:inline">Address</span>
            </button>
            <div className="w-8 h-px bg-primary/30" />
            <button
              type="button"
              className={cn(
                "flex items-center gap-2 px-4 py-2 rounded-full transition-colors",
                step === "payment"
                  ? "bg-primary text-primary-foreground"
                  : "glass text-muted-foreground"
              )}
              onClick={() => selectedAddress && setStep("payment")}
              disabled={!selectedAddress}
            >
              <CreditCard className="w-4 h-4" />
              <span className="hidden sm:inline">Payment</span>
            </button>
            <div className="w-8 h-px bg-primary/30" />
            <button
              type="button"
              className={cn(
                "flex items-center gap-2 px-4 py-2 rounded-full transition-colors",
                step === "confirm"
                  ? "bg-primary text-primary-foreground"
                  : "glass text-muted-foreground"
              )}
              onClick={() =>
                selectedAddress && paymentMethod && setStep("confirm")
              }
              disabled={!selectedAddress || !paymentMethod}
            >
              <Check className="w-4 h-4" />
              <span className="hidden sm:inline">Confirm</span>
            </button>
          </div>
        </div>

        <div className="grid lg:grid-cols-3 gap-8">
          {/* Main Content */}
          <div className="lg:col-span-2">
            {/* Address Step */}
            {step === "address" && (
              <div className="glass-bubble rounded-2xl p-6">
                <h2 className="text-xl font-bold text-foreground mb-6 flex items-center gap-2">
                  <MapPin className="w-5 h-5 text-primary" />
                  Delivery Address
                </h2>

                {/* Existing Addresses */}
                {user?.addresses && user.addresses.length > 0 && (
                  <div className="space-y-4 mb-6">
                    {user.addresses.map((address) => (
                      <button
                        key={address.id}
                        type="button"
                        className={cn(
                          "w-full p-4 rounded-xl text-left transition-all",
                          selectedAddress?.id === address.id
                            ? "glass-card border-primary/50 ring-2 ring-primary/30"
                            : "glass hover:border-primary/30"
                        )}
                        onClick={() => setSelectedAddress(address)}
                      >
                        <div className="flex items-start justify-between">
                          <div>
                            <div className="font-medium text-foreground">
                              {address.name}
                            </div>
                            <div className="text-sm text-muted-foreground mt-1">
                              {address.street}, {address.city}, {address.state} -{" "}
                              {address.pincode}
                            </div>
                            <div className="text-sm text-muted-foreground mt-1">
                              Phone: {address.phone}
                            </div>
                          </div>
                          {selectedAddress?.id === address.id && (
                            <Check className="w-5 h-5 text-primary" />
                          )}
                        </div>
                      </button>
                    ))}
                  </div>
                )}

                {/* Add New Address */}
                {showAddAddress ? (
                  <div className="glass-card rounded-xl p-6 space-y-4">
                    <h3 className="font-medium text-foreground">
                      Add New Address
                    </h3>
                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label className="text-foreground">Full Name</Label>
                        <Input
                          value={newAddress.name}
                          onChange={(e) =>
                            setNewAddress({ ...newAddress, name: e.target.value })
                          }
                          placeholder="John Doe"
                          className="glass border-primary/30 text-foreground placeholder:text-muted-foreground"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label className="text-foreground">Phone Number</Label>
                        <Input
                          value={newAddress.phone}
                          onChange={(e) =>
                            setNewAddress({ ...newAddress, phone: e.target.value })
                          }
                          placeholder="+91 98765 43210"
                          className="glass border-primary/30 text-foreground placeholder:text-muted-foreground"
                        />
                      </div>
                    </div>
                    <div className="space-y-2">
                      <Label className="text-foreground">Street Address</Label>
                      <Input
                        value={newAddress.street}
                        onChange={(e) =>
                          setNewAddress({ ...newAddress, street: e.target.value })
                        }
                        placeholder="House/Flat No., Street, Landmark"
                        className="glass border-primary/30 text-foreground placeholder:text-muted-foreground"
                      />
                    </div>
                    <div className="grid grid-cols-3 gap-4">
                      <div className="space-y-2">
                        <Label className="text-foreground">City</Label>
                        <Input
                          value={newAddress.city}
                          onChange={(e) =>
                            setNewAddress({ ...newAddress, city: e.target.value })
                          }
                          placeholder="Bangalore"
                          className="glass border-primary/30 text-foreground placeholder:text-muted-foreground"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label className="text-foreground">State</Label>
                        <Input
                          value={newAddress.state}
                          onChange={(e) =>
                            setNewAddress({ ...newAddress, state: e.target.value })
                          }
                          placeholder="Karnataka"
                          className="glass border-primary/30 text-foreground placeholder:text-muted-foreground"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label className="text-foreground">Pincode</Label>
                        <Input
                          value={newAddress.pincode}
                          onChange={(e) =>
                            setNewAddress({
                              ...newAddress,
                              pincode: e.target.value,
                            })
                          }
                          placeholder="560001"
                          className="glass border-primary/30 text-foreground placeholder:text-muted-foreground"
                        />
                      </div>
                    </div>
                    <div className="flex gap-4">
                      <Button
                        onClick={handleAddAddress}
                        className="bg-primary hover:bg-primary/80 text-primary-foreground"
                      >
                        Save Address
                      </Button>
                      <Button
                        variant="outline"
                        onClick={() => setShowAddAddress(false)}
                        className="border-primary/30 text-foreground"
                      >
                        Cancel
                      </Button>
                    </div>
                  </div>
                ) : (
                  <Button
                    variant="outline"
                    className="w-full border-dashed border-primary/30 text-foreground hover:bg-primary/10 gap-2 bg-transparent"
                    onClick={() => setShowAddAddress(true)}
                  >
                    <Plus className="w-4 h-4" />
                    Add New Address
                  </Button>
                )}

                <Button
                  className="w-full mt-6 bg-primary hover:bg-primary/80 text-primary-foreground"
                  onClick={() => setStep("payment")}
                  disabled={!selectedAddress}
                >
                  Continue to Payment
                </Button>
              </div>
            )}

            {/* Payment Step */}
            {step === "payment" && (
              <div className="glass-bubble rounded-2xl p-6">
                <h2 className="text-xl font-bold text-foreground mb-6 flex items-center gap-2">
                  <CreditCard className="w-5 h-5 text-primary" />
                  Payment Method
                </h2>

                <div className="space-y-4">
                  {/* COD */}
                  <button
                    type="button"
                    className={cn(
                      "w-full p-4 rounded-xl text-left transition-all",
                      paymentMethod === "cod"
                        ? "glass-card border-primary/50 ring-2 ring-primary/30"
                        : "glass hover:border-primary/30"
                    )}
                    onClick={() => setPaymentMethod("cod")}
                  >
                    <div className="flex items-center gap-4">
                      <div className="w-12 h-12 rounded-full bg-primary/20 flex items-center justify-center">
                        <Banknote className="w-6 h-6 text-primary" />
                      </div>
                      <div>
                        <div className="font-medium text-foreground">
                          Cash on Delivery
                        </div>
                        <div className="text-sm text-muted-foreground">
                          Pay when you receive your order
                        </div>
                      </div>
                      {paymentMethod === "cod" && (
                        <Check className="w-5 h-5 text-primary ml-auto" />
                      )}
                    </div>
                  </button>

                  {/* Card */}
                  <button
                    type="button"
                    className={cn(
                      "w-full p-4 rounded-xl text-left transition-all",
                      paymentMethod === "card"
                        ? "glass-card border-primary/50 ring-2 ring-primary/30"
                        : "glass hover:border-primary/30"
                    )}
                    onClick={() => setPaymentMethod("card")}
                  >
                    <div className="flex items-center gap-4">
                      <div className="w-12 h-12 rounded-full bg-primary/20 flex items-center justify-center">
                        <CreditCard className="w-6 h-6 text-primary" />
                      </div>
                      <div>
                        <div className="font-medium text-foreground">
                          Credit/Debit Card
                        </div>
                        <div className="text-sm text-muted-foreground">
                          Visa, Mastercard, Rupay
                        </div>
                      </div>
                      {paymentMethod === "card" && (
                        <Check className="w-5 h-5 text-primary ml-auto" />
                      )}
                    </div>
                  </button>

                  {/* Card Details */}
                  {paymentMethod === "card" && (
                    <div className="glass-card rounded-xl p-4 space-y-4 ml-8">
                      <div className="space-y-2">
                        <Label className="text-foreground">Card Number</Label>
                        <Input
                          value={cardDetails.number}
                          onChange={(e) =>
                            setCardDetails({
                              ...cardDetails,
                              number: e.target.value,
                            })
                          }
                          placeholder="1234 5678 9012 3456"
                          className="glass border-primary/30 text-foreground placeholder:text-muted-foreground"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label className="text-foreground">Cardholder Name</Label>
                        <Input
                          value={cardDetails.name}
                          onChange={(e) =>
                            setCardDetails({
                              ...cardDetails,
                              name: e.target.value,
                            })
                          }
                          placeholder="John Doe"
                          className="glass border-primary/30 text-foreground placeholder:text-muted-foreground"
                        />
                      </div>
                      <div className="grid grid-cols-2 gap-4">
                        <div className="space-y-2">
                          <Label className="text-foreground">Expiry Date</Label>
                          <Input
                            value={cardDetails.expiry}
                            onChange={(e) =>
                              setCardDetails({
                                ...cardDetails,
                                expiry: e.target.value,
                              })
                            }
                            placeholder="MM/YY"
                            className="glass border-primary/30 text-foreground placeholder:text-muted-foreground"
                          />
                        </div>
                        <div className="space-y-2">
                          <Label className="text-foreground">CVV</Label>
                          <Input
                            value={cardDetails.cvv}
                            onChange={(e) =>
                              setCardDetails({
                                ...cardDetails,
                                cvv: e.target.value,
                              })
                            }
                            placeholder="123"
                            type="password"
                            className="glass border-primary/30 text-foreground placeholder:text-muted-foreground"
                          />
                        </div>
                      </div>
                    </div>
                  )}

                  {/* UPI */}
                  <button
                    type="button"
                    className={cn(
                      "w-full p-4 rounded-xl text-left transition-all",
                      paymentMethod === "upi"
                        ? "glass-card border-primary/50 ring-2 ring-primary/30"
                        : "glass hover:border-primary/30"
                    )}
                    onClick={() => setPaymentMethod("upi")}
                  >
                    <div className="flex items-center gap-4">
                      <div className="w-12 h-12 rounded-full bg-primary/20 flex items-center justify-center">
                        <Smartphone className="w-6 h-6 text-primary" />
                      </div>
                      <div>
                        <div className="font-medium text-foreground">UPI</div>
                        <div className="text-sm text-muted-foreground">
                          Google Pay, PhonePe, Paytm
                        </div>
                      </div>
                      {paymentMethod === "upi" && (
                        <Check className="w-5 h-5 text-primary ml-auto" />
                      )}
                    </div>
                  </button>

                  {/* UPI ID */}
                  {paymentMethod === "upi" && (
                    <div className="glass-card rounded-xl p-4 ml-8">
                      <div className="space-y-2">
                        <Label className="text-foreground">UPI ID</Label>
                        <Input
                          value={upiId}
                          onChange={(e) => setUpiId(e.target.value)}
                          placeholder="yourname@upi"
                          className="glass border-primary/30 text-foreground placeholder:text-muted-foreground"
                        />
                      </div>
                    </div>
                  )}
                </div>

                <div className="flex gap-4 mt-6">
                  <Button
                    variant="outline"
                    className="border-primary/30 text-foreground bg-transparent"
                    onClick={() => setStep("address")}
                  >
                    <ArrowLeft className="w-4 h-4 mr-2" />
                    Back
                  </Button>
                  <Button
                    className="flex-1 bg-primary hover:bg-primary/80 text-primary-foreground"
                    onClick={() => setStep("confirm")}
                  >
                    Review Order
                  </Button>
                </div>
              </div>
            )}

            {/* Confirm Step */}
            {step === "confirm" && (
              <div className="space-y-6">
                {/* Delivery Address */}
                <div className="glass-bubble rounded-2xl p-6">
                  <div className="flex items-center justify-between mb-4">
                    <h3 className="font-semibold text-foreground flex items-center gap-2">
                      <MapPin className="w-5 h-5 text-primary" />
                      Delivery Address
                    </h3>
                    <Button
                      variant="ghost"
                      size="sm"
                      className="text-primary"
                      onClick={() => setStep("address")}
                    >
                      Change
                    </Button>
                  </div>
                  {selectedAddress && (
                    <div>
                      <div className="font-medium text-foreground">
                        {selectedAddress.name}
                      </div>
                      <div className="text-sm text-muted-foreground">
                        {selectedAddress.street}, {selectedAddress.city},{" "}
                        {selectedAddress.state} - {selectedAddress.pincode}
                      </div>
                      <div className="text-sm text-muted-foreground">
                        Phone: {selectedAddress.phone}
                      </div>
                    </div>
                  )}
                </div>

                {/* Payment Method */}
                <div className="glass-bubble rounded-2xl p-6">
                  <div className="flex items-center justify-between mb-4">
                    <h3 className="font-semibold text-foreground flex items-center gap-2">
                      <CreditCard className="w-5 h-5 text-primary" />
                      Payment Method
                    </h3>
                    <Button
                      variant="ghost"
                      size="sm"
                      className="text-primary"
                      onClick={() => setStep("payment")}
                    >
                      Change
                    </Button>
                  </div>
                  <div className="font-medium text-foreground">
                    {paymentMethod === "cod"
                      ? "Cash on Delivery"
                      : paymentMethod === "card"
                      ? "Credit/Debit Card"
                      : "UPI"}
                  </div>
                </div>

                {/* Order Items */}
                <div className="glass-bubble rounded-2xl p-6">
                  <h3 className="font-semibold text-foreground mb-4">
                    Order Items ({cart.length})
                  </h3>
                  <div className="space-y-4">
                    {cart.map((item) => (
                      <div key={item.id} className="flex gap-4">
                        <div className="relative w-16 h-16 rounded-lg overflow-hidden">
                          <Image
                            src={item.image || "/placeholder.svg"}
                            alt={item.name}
                            fill
                            className="object-cover"
                            sizes="64px"
                          />
                        </div>
                        <div className="flex-1">
                          <div className="font-medium text-foreground line-clamp-1">
                            {item.name}
                          </div>
                          <div className="text-sm text-muted-foreground">
                            Qty: {item.quantity}
                          </div>
                          <div className="font-medium text-foreground">
                            Rs.{(item.price * item.quantity).toLocaleString()}
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="flex gap-4">
                  <Button
                    variant="outline"
                    className="border-primary/30 text-foreground bg-transparent"
                    onClick={() => setStep("payment")}
                  >
                    <ArrowLeft className="w-4 h-4 mr-2" />
                    Back
                  </Button>
                  <Button
                    className="flex-1 bg-primary hover:bg-primary/80 text-primary-foreground h-12 text-lg"
                    onClick={handlePlaceOrder}
                    disabled={loading}
                  >
                    {loading ? (
                      "Processing..."
                    ) : (
                      <>
                        Place Order - Rs.{finalTotal.toLocaleString()}
                      </>
                    )}
                  </Button>
                </div>
              </div>
            )}
          </div>

          {/* Order Summary Sidebar */}
          <div className="lg:col-span-1">
            <div className="glass-bubble rounded-2xl p-6 sticky top-24">
              <h2 className="text-xl font-bold text-foreground mb-6">
                Order Summary
              </h2>

              {/* Items Preview */}
              <div className="space-y-3 mb-6 max-h-48 overflow-y-auto">
                {cart.slice(0, 3).map((item) => (
                  <div key={item.id} className="flex items-center gap-3">
                    <div className="relative w-12 h-12 rounded-lg overflow-hidden">
                      <Image
                        src={item.image || "/placeholder.svg"}
                        alt={item.name}
                        fill
                        className="object-cover"
                        sizes="48px"
                      />
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="text-sm font-medium text-foreground truncate">
                        {item.name}
                      </div>
                      <div className="text-xs text-muted-foreground">
                        x{item.quantity}
                      </div>
                    </div>
                    <div className="text-sm font-medium text-foreground">
                      Rs.{(item.price * item.quantity).toLocaleString()}
                    </div>
                  </div>
                ))}
                {cart.length > 3 && (
                  <div className="text-sm text-muted-foreground text-center">
                    +{cart.length - 3} more items
                  </div>
                )}
              </div>

              {/* Price Breakdown */}
              <div className="space-y-3 border-t border-primary/20 pt-4">
                <div className="flex justify-between text-muted-foreground">
                  <span>Subtotal</span>
                  <span className="text-foreground">
                    Rs.{cartTotal.toLocaleString()}
                  </span>
                </div>
                {discountAmount > 0 && (
                  <div className="flex justify-between text-green-500">
                    <span>Discount ({discount}%)</span>
                    <span>-Rs.{discountAmount.toLocaleString()}</span>
                  </div>
                )}
                <div className="flex justify-between text-muted-foreground">
                  <span>Delivery</span>
                  <span className="text-foreground">
                    {deliveryCharge === 0 ? (
                      <span className="text-green-500">FREE</span>
                    ) : (
                      `Rs.${deliveryCharge}`
                    )}
                  </span>
                </div>
                <div className="border-t border-primary/20 pt-3 flex justify-between">
                  <span className="text-lg font-bold text-foreground">Total</span>
                  <span className="text-lg font-bold text-foreground">
                    Rs.{finalTotal.toLocaleString()}
                  </span>
                </div>
              </div>

              {/* Trust Badges */}
              <div className="mt-6 pt-4 border-t border-primary/20 space-y-3">
                <div className="flex items-center gap-2 text-sm text-muted-foreground">
                  <Shield className="w-4 h-4 text-primary" />
                  <span>100% Secure Payments</span>
                </div>
                <div className="flex items-center gap-2 text-sm text-muted-foreground">
                  <Truck className="w-4 h-4 text-primary" />
                  <span>Free Delivery on orders above Rs.499</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
}
