import React from "react"
import type { Metadata, Viewport } from "next";
import { Inter, Poppins } from "next/font/google";
import { Analytics } from "@vercel/analytics/next";
import "./globals.css";
import { StoreProvider } from "@/context/store-context";
import { Toaster } from "@/components/ui/toaster";

const inter = Inter({ subsets: ["latin"], variable: "--font-inter" });
const poppins = Poppins({
  subsets: ["latin"],
  weight: ["400", "500", "600", "700", "800"],
  variable: "--font-poppins",
});

export const metadata: Metadata = {
  title: "ADmart - Shop Smart, Live Better",
  description:
    "Discover amazing deals on electronics, fashion, home essentials and more. Free shipping, easy returns, and secure payments.",
  generator: "ADmart",
  keywords: [
    "online shopping",
    "ecommerce",
    "deals",
    "discounts",
    "electronics",
    "fashion",
  ],
  icons: {
    icon: [
      {
        url: "/icon-light-32x32.png",
        media: "(prefers-color-scheme: light)",
      },
      {
        url: "/icon-dark-32x32.png",
        media: "(prefers-color-scheme: dark)",
      },
      {
        url: "/icon.svg",
        type: "image/svg+xml",
      },
    ],
    apple: "/apple-icon.png",
  },
};

export const viewport: Viewport = {
  themeColor: "#1a1025",
  width: "device-width",
  initialScale: 1,
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" className="dark">
      <body
        className={`${inter.variable} ${poppins.variable} font-sans antialiased min-h-screen`}
      >
        <StoreProvider>
          {children}
          <Toaster />
        </StoreProvider>
        <Analytics />
      </body>
    </html>
  );
}
