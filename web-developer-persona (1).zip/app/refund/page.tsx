"use client";

import { useState } from "react";
import Link from "next/link";
import { Header } from "@/components/layout/header";
import { Footer } from "@/components/layout/footer";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  RotateCcw,
  Package,
  CheckCircle,
  Clock,
  CreditCard,
  AlertCircle,
  ArrowRight,
  Search,
  ShieldCheck,
  Truck,
  Ban,
} from "lucide-react";

const refundSteps = [
  {
    step: 1,
    title: "Request Return",
    description: "Go to My Orders and select the item you want to return",
    icon: Package,
  },
  {
    step: 2,
    title: "Schedule Pickup",
    description: "Choose a convenient time for our delivery partner to pick up",
    icon: Truck,
  },
  {
    step: 3,
    title: "Quality Check",
    description: "We will inspect the returned item at our warehouse",
    icon: ShieldCheck,
  },
  {
    step: 4,
    title: "Refund Processed",
    description: "Amount credited to your original payment method",
    icon: CreditCard,
  },
];

const refundPolicies = [
  {
    category: "Electronics",
    returnWindow: "7 days",
    condition: "Replacement only",
    icon: "📱",
  },
  {
    category: "Fashion",
    returnWindow: "30 days",
    condition: "Return & Refund",
    icon: "👕",
  },
  {
    category: "Home & Kitchen",
    returnWindow: "10 days",
    condition: "Return & Refund",
    icon: "🏠",
  },
  {
    category: "Books",
    returnWindow: "7 days",
    condition: "Return if damaged",
    icon: "📚",
  },
  {
    category: "Beauty",
    returnWindow: "15 days",
    condition: "Unopened only",
    icon: "💄",
  },
  {
    category: "Sports",
    returnWindow: "10 days",
    condition: "Return & Refund",
    icon: "⚽",
  },
];

const sampleRefunds = [
  {
    id: "REF123456",
    orderId: "ADM1706234567",
    product: "Sony WH-1000XM5 Headphones",
    amount: 29990,
    status: "completed",
    date: "Jan 20, 2026",
    refundDate: "Jan 25, 2026",
  },
  {
    id: "REF123457",
    orderId: "ADM1706234568",
    product: "Nike Air Max Sneakers",
    amount: 8999,
    status: "processing",
    date: "Jan 28, 2026",
    expectedDate: "Feb 2, 2026",
  },
];

export default function RefundPage() {
  const [trackingId, setTrackingId] = useState("");
  const [activeTab, setActiveTab] = useState("policy");

  return (
    <div className="min-h-screen bg-background">
      <Header />
      <main className="container mx-auto px-4 py-8">
        {/* Hero */}
        <div className="text-center mb-12">
          <RotateCcw className="w-16 h-16 mx-auto mb-4 text-primary bubble-float" />
          <h1 className="text-4xl font-bold mb-4">Returns & Refunds</h1>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Easy returns, hassle-free refunds. We have got you covered.
          </p>
        </div>

        {/* Tabs */}
        <div className="flex justify-center gap-4 mb-8">
          {[
            { id: "policy", label: "Return Policy" },
            { id: "track", label: "Track Refund" },
            { id: "history", label: "Refund History" },
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`px-6 py-3 rounded-full transition-all ${
                activeTab === tab.id
                  ? "bg-primary text-primary-foreground glow-purple"
                  : "glass-card hover:bg-secondary"
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>

        {activeTab === "policy" && (
          <>
            {/* How It Works */}
            <div className="glass-bubble rounded-3xl p-8 mb-8">
              <h2 className="text-2xl font-bold mb-8 text-center">How Returns Work</h2>
              <div className="grid md:grid-cols-4 gap-6">
                {refundSteps.map((step, idx) => (
                  <div key={step.step} className="relative">
                    {idx < refundSteps.length - 1 && (
                      <div className="hidden md:block absolute top-8 left-1/2 w-full h-0.5 bg-gradient-to-r from-primary to-transparent" />
                    )}
                    <div className="glass-card rounded-2xl p-6 text-center relative z-10">
                      <div className="w-16 h-16 rounded-full bg-primary/20 flex items-center justify-center mx-auto mb-4">
                        <step.icon className="w-8 h-8 text-primary" />
                      </div>
                      <div className="absolute -top-3 -right-3 w-8 h-8 rounded-full bg-primary flex items-center justify-center text-primary-foreground font-bold">
                        {step.step}
                      </div>
                      <h3 className="font-semibold mb-2">{step.title}</h3>
                      <p className="text-sm text-muted-foreground">{step.description}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Category-wise Policy */}
            <div className="glass-bubble rounded-3xl p-8 mb-8">
              <h2 className="text-2xl font-bold mb-6">Return Windows by Category</h2>
              <div className="grid md:grid-cols-3 gap-4">
                {refundPolicies.map((policy) => (
                  <div key={policy.category} className="glass-card rounded-xl p-5">
                    <div className="flex items-center gap-3 mb-3">
                      <span className="text-2xl">{policy.icon}</span>
                      <h3 className="font-semibold">{policy.category}</h3>
                    </div>
                    <div className="space-y-2 text-sm">
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">Return Window</span>
                        <span className="font-medium text-primary">{policy.returnWindow}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">Condition</span>
                        <span>{policy.condition}</span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Non-Returnable Items */}
            <div className="glass-bubble rounded-3xl p-8">
              <div className="flex items-center gap-3 mb-6">
                <Ban className="w-6 h-6 text-destructive" />
                <h2 className="text-2xl font-bold">Non-Returnable Items</h2>
              </div>
              <div className="grid md:grid-cols-2 gap-4">
                {[
                  "Innerwear, lingerie & swimwear",
                  "Customized or personalized products",
                  "Perishable goods & groceries",
                  "Digital products & gift cards",
                  "Products with broken seal/packaging",
                  "Items marked as non-returnable",
                ].map((item) => (
                  <div key={item} className="flex items-center gap-3 text-muted-foreground">
                    <AlertCircle className="w-4 h-4 text-destructive flex-shrink-0" />
                    <span>{item}</span>
                  </div>
                ))}
              </div>
            </div>
          </>
        )}

        {activeTab === "track" && (
          <div className="max-w-2xl mx-auto">
            <div className="glass-bubble rounded-3xl p-8">
              <h2 className="text-2xl font-bold mb-6 text-center">Track Your Refund</h2>
              <div className="flex gap-4 mb-8">
                <div className="flex-1 relative">
                  <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
                  <Input
                    value={trackingId}
                    onChange={(e) => setTrackingId(e.target.value)}
                    placeholder="Enter Refund ID or Order ID"
                    className="pl-12 h-12"
                  />
                </div>
                <Button className="h-12 px-6 bg-primary hover:bg-primary/90 gap-2">
                  Track
                  <ArrowRight className="w-4 h-4" />
                </Button>
              </div>

              {/* Sample Refund Status */}
              <div className="glass-card rounded-2xl p-6">
                <div className="flex items-center justify-between mb-6">
                  <div>
                    <p className="text-sm text-muted-foreground">Refund ID: REF123457</p>
                    <p className="font-semibold">Nike Air Max Sneakers</p>
                  </div>
                  <div className="text-right">
                    <p className="text-sm text-muted-foreground">Refund Amount</p>
                    <p className="font-bold text-primary text-xl">Rs. 8,999</p>
                  </div>
                </div>

                <div className="relative">
                  {[
                    { label: "Return Requested", date: "Jan 28", done: true },
                    { label: "Item Picked Up", date: "Jan 29", done: true },
                    { label: "Quality Check", date: "Jan 30", done: true },
                    { label: "Refund Initiated", date: "Jan 31", done: false },
                    { label: "Refund Credited", date: "Expected: Feb 2", done: false },
                  ].map((step, idx) => (
                    <div key={step.label} className="flex gap-4 pb-6 last:pb-0">
                      {idx < 4 && (
                        <div
                          className={`absolute left-6 top-0 w-0.5 h-full -translate-x-1/2 ${
                            step.done ? "bg-primary" : "bg-border"
                          }`}
                          style={{ top: `${idx * 60 + 24}px`, height: "60px" }}
                        />
                      )}
                      <div
                        className={`relative z-10 w-12 h-12 rounded-full flex items-center justify-center flex-shrink-0 ${
                          step.done
                            ? "bg-primary text-primary-foreground"
                            : "bg-secondary text-muted-foreground"
                        }`}
                      >
                        {step.done ? <CheckCircle className="w-5 h-5" /> : <Clock className="w-5 h-5" />}
                      </div>
                      <div className="flex-1 flex items-center justify-between">
                        <span className={step.done ? "font-medium" : "text-muted-foreground"}>
                          {step.label}
                        </span>
                        <span className="text-sm text-muted-foreground">{step.date}</span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        )}

        {activeTab === "history" && (
          <div className="max-w-4xl mx-auto">
            <div className="glass-bubble rounded-3xl p-8">
              <h2 className="text-2xl font-bold mb-6">Refund History</h2>
              {sampleRefunds.length === 0 ? (
                <div className="text-center py-12">
                  <RotateCcw className="w-12 h-12 mx-auto mb-4 text-muted-foreground" />
                  <p className="text-muted-foreground">No refunds yet</p>
                </div>
              ) : (
                <div className="space-y-4">
                  {sampleRefunds.map((refund) => (
                    <div key={refund.id} className="glass-card rounded-xl p-5">
                      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                        <div>
                          <div className="flex items-center gap-3 mb-2">
                            <span
                              className={`px-3 py-1 rounded-full text-xs font-medium ${
                                refund.status === "completed"
                                  ? "bg-green-500/20 text-green-500"
                                  : "bg-yellow-500/20 text-yellow-500"
                              }`}
                            >
                              {refund.status === "completed" ? "Refund Completed" : "Processing"}
                            </span>
                            <span className="text-sm text-muted-foreground">{refund.id}</span>
                          </div>
                          <p className="font-medium">{refund.product}</p>
                          <p className="text-sm text-muted-foreground">Order: {refund.orderId}</p>
                        </div>
                        <div className="text-right">
                          <p className="text-2xl font-bold text-gradient">
                            Rs. {refund.amount.toLocaleString("en-IN")}
                          </p>
                          <p className="text-sm text-muted-foreground">
                            {refund.status === "completed"
                              ? `Refunded on ${refund.refundDate}`
                              : `Expected by ${refund.expectedDate}`}
                          </p>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        )}

        {/* CTA */}
        <div className="text-center mt-12">
          <p className="text-muted-foreground mb-4">Need help with a return?</p>
          <Link href="/support">
            <Button variant="outline" className="gap-2 bg-transparent">
              Contact Support
              <ArrowRight className="w-4 h-4" />
            </Button>
          </Link>
        </div>
      </main>
      <Footer />
    </div>
  );
}
