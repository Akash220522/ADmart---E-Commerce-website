"use client";

import { Suspense } from "react";
import { useSearchParams } from "next/navigation";
import Link from "next/link";
import { CheckCircle2, Package, Truck, Home as HomeIcon, ArrowRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Header } from "@/components/layout/header";
import { Footer } from "@/components/layout/footer";

function OrderSuccessContent() {
  const searchParams = useSearchParams();
  const orderId = searchParams.get("id") || "ADM123456";

  return (
    <div className="max-w-2xl mx-auto">
      <div className="glass-bubble rounded-3xl p-8 md:p-12 text-center">
        {/* Success Icon */}
        <div className="relative w-24 h-24 mx-auto mb-8">
          <div className="absolute inset-0 rounded-full bg-green-500/20 animate-ping" />
          <div className="relative w-24 h-24 rounded-full bg-green-500/30 flex items-center justify-center">
            <CheckCircle2 className="w-14 h-14 text-green-500" />
          </div>
        </div>

        <h1 className="text-2xl md:text-3xl font-bold text-foreground mb-4">
          Order Placed Successfully!
        </h1>
        <p className="text-muted-foreground mb-2">
          Thank you for your purchase. Your order has been confirmed.
        </p>
        <p className="text-lg font-medium text-primary mb-8">
          Order ID: {orderId}
        </p>

        {/* Order Timeline */}
        <div className="glass-card rounded-2xl p-6 mb-8">
          <h3 className="font-semibold text-foreground mb-6">
            What happens next?
          </h3>
          <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 rounded-full bg-primary/20 flex items-center justify-center">
                <CheckCircle2 className="w-6 h-6 text-primary" />
              </div>
              <div className="text-left">
                <div className="font-medium text-foreground">Order Confirmed</div>
                <div className="text-sm text-muted-foreground">Just now</div>
              </div>
            </div>
            <div className="hidden md:block w-16 h-px bg-primary/30" />
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 rounded-full bg-muted/50 flex items-center justify-center">
                <Package className="w-6 h-6 text-muted-foreground" />
              </div>
              <div className="text-left">
                <div className="font-medium text-foreground">Processing</div>
                <div className="text-sm text-muted-foreground">1-2 days</div>
              </div>
            </div>
            <div className="hidden md:block w-16 h-px bg-primary/30" />
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 rounded-full bg-muted/50 flex items-center justify-center">
                <Truck className="w-6 h-6 text-muted-foreground" />
              </div>
              <div className="text-left">
                <div className="font-medium text-foreground">Shipped</div>
                <div className="text-sm text-muted-foreground">2-4 days</div>
              </div>
            </div>
            <div className="hidden md:block w-16 h-px bg-primary/30" />
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 rounded-full bg-muted/50 flex items-center justify-center">
                <HomeIcon className="w-6 h-6 text-muted-foreground" />
              </div>
              <div className="text-left">
                <div className="font-medium text-foreground">Delivered</div>
                <div className="text-sm text-muted-foreground">5-7 days</div>
              </div>
            </div>
          </div>
        </div>

        {/* Actions */}
        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <Link href="/orders">
            <Button className="w-full sm:w-auto bg-primary hover:bg-primary/80 text-primary-foreground gap-2">
              Track Order
              <ArrowRight className="w-4 h-4" />
            </Button>
          </Link>
          <Link href="/">
            <Button
              variant="outline"
              className="w-full sm:w-auto border-primary/30 text-foreground hover:bg-primary/10 bg-transparent"
            >
              Continue Shopping
            </Button>
          </Link>
        </div>
      </div>

      {/* Additional Info */}
      <div className="grid md:grid-cols-2 gap-4 mt-8">
        <div className="glass-card rounded-xl p-4 text-center">
          <div className="text-sm text-muted-foreground mb-1">
            Need Help?
          </div>
          <Link
            href="/support"
            className="text-primary hover:underline font-medium"
          >
            Contact Support
          </Link>
        </div>
        <div className="glass-card rounded-xl p-4 text-center">
          <div className="text-sm text-muted-foreground mb-1">
            Order Updates
          </div>
          <span className="text-foreground font-medium">
            Sent to your email
          </span>
        </div>
      </div>
    </div>
  );
}

export default function OrderSuccessPage() {
  return (
    <div className="min-h-screen bg-background">
      <Header />
      <main className="max-w-7xl mx-auto px-4 py-12">
        <Suspense
          fallback={
            <div className="text-center py-20 text-muted-foreground">
              Loading...
            </div>
          }
        >
          <OrderSuccessContent />
        </Suspense>
      </main>
      <Footer />
    </div>
  );
}
