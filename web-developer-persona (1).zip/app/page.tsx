import { Header } from "@/components/layout/header";
import { Footer } from "@/components/layout/footer";
import { HeroSection } from "@/components/home/hero-section";
import { CategorySection } from "@/components/home/category-section";
import { DealsSection } from "@/components/home/deals-section";
import { ProductsSection } from "@/components/home/products-section";

export default function HomePage() {
  return (
    <div className="min-h-screen bg-background">
      <Header />
      <main>
        <HeroSection />
        <CategorySection />
        <DealsSection />
        <ProductsSection />
      </main>
      <Footer />
    </div>
  );
}
