"use client";

import { useState } from "react";
import Link from "next/link";
import { Header } from "@/components/layout/header";
import { Footer } from "@/components/layout/footer";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useStore } from "@/context/store-context";
import {
  User,
  MapPin,
  Phone,
  Mail,
  Package,
  Heart,
  CreditCard,
  LogOut,
  Edit2,
  Plus,
  Trash2,
  ChevronRight,
} from "lucide-react";

export default function ProfilePage() {
  const { user, isAuthenticated, addresses, addAddress, removeAddress, logout } = useStore();
  const [activeTab, setActiveTab] = useState("profile");
  const [isAddingAddress, setIsAddingAddress] = useState(false);
  const [newAddress, setNewAddress] = useState({
    name: "",
    phone: "",
    street: "",
    city: "",
    state: "",
    pincode: "",
    type: "home" as "home" | "work" | "other",
  });

  const handleAddAddress = () => {
    if (newAddress.name && newAddress.phone && newAddress.street && newAddress.city && newAddress.pincode) {
      addAddress({
        ...newAddress,
        isDefault: addresses.length === 0,
      });
      setNewAddress({ name: "", phone: "", street: "", city: "", state: "", pincode: "", type: "home" });
      setIsAddingAddress(false);
    }
  };

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-background">
        <Header />
        <main className="container mx-auto px-4 py-20">
          <div className="glass-bubble rounded-3xl p-12 text-center max-w-md mx-auto">
            <User className="w-16 h-16 mx-auto mb-4 text-primary" />
            <h1 className="text-2xl font-bold mb-4">Sign in to your account</h1>
            <p className="text-muted-foreground mb-6">
              Access your profile, orders, and saved addresses
            </p>
            <Link href="/signin">
              <Button className="w-full bg-primary hover:bg-primary/90">Sign In</Button>
            </Link>
            <p className="mt-4 text-sm text-muted-foreground">
              New to ADmart?{" "}
              <Link href="/signup" className="text-primary hover:underline">
                Create an account
              </Link>
            </p>
          </div>
        </main>
        <Footer />
      </div>
    );
  }

  const tabs = [
    { id: "profile", label: "My Profile", icon: User },
    { id: "addresses", label: "Addresses", icon: MapPin },
    { id: "orders", label: "My Orders", icon: Package },
    { id: "wishlist", label: "Wishlist", icon: Heart },
    { id: "payments", label: "Payment Methods", icon: CreditCard },
  ];

  return (
    <div className="min-h-screen bg-background">
      <Header />
      <main className="container mx-auto px-4 py-8">
        <h1 className="text-3xl font-bold mb-8">My Account</h1>

        <div className="grid lg:grid-cols-4 gap-8">
          {/* Sidebar */}
          <div className="lg:col-span-1">
            <div className="glass-bubble rounded-2xl p-6">
              <div className="flex items-center gap-4 mb-6 pb-6 border-b border-border">
                <div className="w-16 h-16 rounded-full bg-primary/20 flex items-center justify-center">
                  <User className="w-8 h-8 text-primary" />
                </div>
                <div>
                  <p className="font-semibold">{user?.name}</p>
                  <p className="text-sm text-muted-foreground">{user?.email}</p>
                </div>
              </div>

              <nav className="space-y-2">
                {tabs.map((tab) => (
                  <button
                    key={tab.id}
                    onClick={() => setActiveTab(tab.id)}
                    className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all ${
                      activeTab === tab.id
                        ? "bg-primary text-primary-foreground"
                        : "hover:bg-secondary"
                    }`}
                  >
                    <tab.icon className="w-5 h-5" />
                    <span>{tab.label}</span>
                    <ChevronRight className="w-4 h-4 ml-auto" />
                  </button>
                ))}

                <button
                  onClick={logout}
                  className="w-full flex items-center gap-3 px-4 py-3 rounded-xl text-destructive hover:bg-destructive/10 transition-all"
                >
                  <LogOut className="w-5 h-5" />
                  <span>Logout</span>
                </button>
              </nav>
            </div>
          </div>

          {/* Content */}
          <div className="lg:col-span-3">
            {activeTab === "profile" && (
              <div className="glass-bubble rounded-2xl p-8">
                <div className="flex items-center justify-between mb-6">
                  <h2 className="text-xl font-semibold">Personal Information</h2>
                  <Button variant="outline" size="sm" className="gap-2 bg-transparent">
                    <Edit2 className="w-4 h-4" />
                    Edit
                  </Button>
                </div>

                <div className="grid md:grid-cols-2 gap-6">
                  <div>
                    <Label className="text-muted-foreground">Full Name</Label>
                    <p className="font-medium mt-1">{user?.name}</p>
                  </div>
                  <div>
                    <Label className="text-muted-foreground">Email Address</Label>
                    <p className="font-medium mt-1 flex items-center gap-2">
                      <Mail className="w-4 h-4" />
                      {user?.email}
                    </p>
                  </div>
                  <div>
                    <Label className="text-muted-foreground">Phone Number</Label>
                    <p className="font-medium mt-1 flex items-center gap-2">
                      <Phone className="w-4 h-4" />
                      {user?.phone || "+91 9876543210"}
                    </p>
                  </div>
                  <div>
                    <Label className="text-muted-foreground">Member Since</Label>
                    <p className="font-medium mt-1">January 2024</p>
                  </div>
                </div>
              </div>
            )}

            {activeTab === "addresses" && (
              <div className="glass-bubble rounded-2xl p-8">
                <div className="flex items-center justify-between mb-6">
                  <h2 className="text-xl font-semibold">Saved Addresses</h2>
                  <Button
                    onClick={() => setIsAddingAddress(true)}
                    className="gap-2 bg-primary hover:bg-primary/90"
                  >
                    <Plus className="w-4 h-4" />
                    Add New
                  </Button>
                </div>

                {isAddingAddress && (
                  <div className="glass-card rounded-xl p-6 mb-6">
                    <h3 className="font-semibold mb-4">Add New Address</h3>
                    <div className="grid md:grid-cols-2 gap-4">
                      <div>
                        <Label>Full Name</Label>
                        <Input
                          value={newAddress.name}
                          onChange={(e) => setNewAddress({ ...newAddress, name: e.target.value })}
                          placeholder="Enter full name"
                          className="mt-1"
                        />
                      </div>
                      <div>
                        <Label>Phone Number</Label>
                        <Input
                          value={newAddress.phone}
                          onChange={(e) => setNewAddress({ ...newAddress, phone: e.target.value })}
                          placeholder="Enter phone number"
                          className="mt-1"
                        />
                      </div>
                      <div className="md:col-span-2">
                        <Label>Street Address</Label>
                        <Input
                          value={newAddress.street}
                          onChange={(e) => setNewAddress({ ...newAddress, street: e.target.value })}
                          placeholder="House no, Building, Street"
                          className="mt-1"
                        />
                      </div>
                      <div>
                        <Label>City</Label>
                        <Input
                          value={newAddress.city}
                          onChange={(e) => setNewAddress({ ...newAddress, city: e.target.value })}
                          placeholder="Enter city"
                          className="mt-1"
                        />
                      </div>
                      <div>
                        <Label>State</Label>
                        <Input
                          value={newAddress.state}
                          onChange={(e) => setNewAddress({ ...newAddress, state: e.target.value })}
                          placeholder="Enter state"
                          className="mt-1"
                        />
                      </div>
                      <div>
                        <Label>PIN Code</Label>
                        <Input
                          value={newAddress.pincode}
                          onChange={(e) => setNewAddress({ ...newAddress, pincode: e.target.value })}
                          placeholder="Enter PIN code"
                          className="mt-1"
                        />
                      </div>
                      <div>
                        <Label>Address Type</Label>
                        <div className="flex gap-2 mt-2">
                          {["home", "work", "other"].map((type) => (
                            <button
                              key={type}
                              onClick={() => setNewAddress({ ...newAddress, type: type as "home" | "work" | "other" })}
                              className={`px-4 py-2 rounded-lg text-sm capitalize transition-all ${
                                newAddress.type === type
                                  ? "bg-primary text-primary-foreground"
                                  : "bg-secondary hover:bg-secondary/80"
                              }`}
                            >
                              {type}
                            </button>
                          ))}
                        </div>
                      </div>
                    </div>
                    <div className="flex gap-3 mt-6">
                      <Button onClick={handleAddAddress} className="bg-primary hover:bg-primary/90">
                        Save Address
                      </Button>
                      <Button variant="outline" onClick={() => setIsAddingAddress(false)}>
                        Cancel
                      </Button>
                    </div>
                  </div>
                )}

                {addresses.length === 0 && !isAddingAddress ? (
                  <div className="text-center py-12">
                    <MapPin className="w-12 h-12 mx-auto mb-4 text-muted-foreground" />
                    <p className="text-muted-foreground">No saved addresses yet</p>
                  </div>
                ) : (
                  <div className="grid md:grid-cols-2 gap-4">
                    {addresses.map((address) => (
                      <div key={address.id} className="glass-card rounded-xl p-5 relative">
                        {address.isDefault && (
                          <span className="absolute top-3 right-3 text-xs bg-primary/20 text-primary px-2 py-1 rounded-full">
                            Default
                          </span>
                        )}
                        <div className="flex items-start gap-3">
                          <MapPin className="w-5 h-5 text-primary mt-1" />
                          <div className="flex-1">
                            <p className="font-semibold">{address.name}</p>
                            <p className="text-sm text-muted-foreground mt-1">
                              {address.street}, {address.city}, {address.state} - {address.pincode}
                            </p>
                            <p className="text-sm text-muted-foreground mt-1">
                              Phone: {address.phone}
                            </p>
                            <span className="inline-block mt-2 text-xs bg-secondary px-2 py-1 rounded capitalize">
                              {address.type}
                            </span>
                          </div>
                        </div>
                        <div className="flex gap-2 mt-4">
                          <Button variant="outline" size="sm">
                            Edit
                          </Button>
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => removeAddress(address.id)}
                            className="text-destructive hover:bg-destructive/10"
                          >
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            )}

            {activeTab === "orders" && (
              <div className="glass-bubble rounded-2xl p-8">
                <h2 className="text-xl font-semibold mb-6">My Orders</h2>
                <div className="text-center py-12">
                  <Package className="w-12 h-12 mx-auto mb-4 text-muted-foreground" />
                  <p className="text-muted-foreground mb-4">No orders yet</p>
                  <Link href="/">
                    <Button className="bg-primary hover:bg-primary/90">Start Shopping</Button>
                  </Link>
                </div>
              </div>
            )}

            {activeTab === "wishlist" && (
              <div className="glass-bubble rounded-2xl p-8">
                <h2 className="text-xl font-semibold mb-6">My Wishlist</h2>
                <div className="text-center py-12">
                  <Heart className="w-12 h-12 mx-auto mb-4 text-muted-foreground" />
                  <p className="text-muted-foreground mb-4">Your wishlist is empty</p>
                  <Link href="/">
                    <Button className="bg-primary hover:bg-primary/90">Browse Products</Button>
                  </Link>
                </div>
              </div>
            )}

            {activeTab === "payments" && (
              <div className="glass-bubble rounded-2xl p-8">
                <div className="flex items-center justify-between mb-6">
                  <h2 className="text-xl font-semibold">Payment Methods</h2>
                  <Button className="gap-2 bg-primary hover:bg-primary/90">
                    <Plus className="w-4 h-4" />
                    Add Card
                  </Button>
                </div>
                <div className="text-center py-12">
                  <CreditCard className="w-12 h-12 mx-auto mb-4 text-muted-foreground" />
                  <p className="text-muted-foreground">No saved payment methods</p>
                </div>
              </div>
            )}
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
}
