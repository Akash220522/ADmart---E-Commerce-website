"use client";

import Link from "next/link";
import { Heart, ArrowRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Header } from "@/components/layout/header";
import { Footer } from "@/components/layout/footer";
import { ProductCard } from "@/components/product/product-card";
import { useStore } from "@/context/store-context";

export default function WishlistPage() {
  const { wishlist } = useStore();

  return (
    <div className="min-h-screen bg-background">
      <Header />
      <main className="max-w-7xl mx-auto px-4 py-8">
        <h1 className="text-2xl md:text-3xl font-bold text-foreground mb-8">
          My Wishlist ({wishlist.length} items)
        </h1>

        {wishlist.length > 0 ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {wishlist.map((product) => (
              <ProductCard key={product.id} product={product} />
            ))}
          </div>
        ) : (
          <div className="glass-bubble rounded-3xl p-12 text-center max-w-lg mx-auto">
            <div className="w-20 h-20 rounded-full bg-primary/20 flex items-center justify-center mx-auto mb-6">
              <Heart className="w-10 h-10 text-primary" />
            </div>
            <h2 className="text-2xl font-bold text-foreground mb-4">
              Your Wishlist is Empty
            </h2>
            <p className="text-muted-foreground mb-8">
              Save your favorite items here by clicking the heart icon on
              products you love.
            </p>
            <Link href="/">
              <Button className="bg-primary hover:bg-primary/80 text-primary-foreground gap-2">
                Explore Products
                <ArrowRight className="w-4 h-4" />
              </Button>
            </Link>
          </div>
        )}
      </main>
      <Footer />
    </div>
  );
}
