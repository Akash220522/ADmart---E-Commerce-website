"use client";

import Link from "next/link";
import { ChevronRight, Zap, Timer } from "lucide-react";
import { Header } from "@/components/layout/header";
import { Footer } from "@/components/layout/footer";
import { ProductCard } from "@/components/product/product-card";
import { getDeals, products } from "@/lib/products";
import { useEffect, useState } from "react";

export default function DealsPage() {
  const deals = getDeals();
  const allDeals = products.filter((p) => p.discount && p.discount > 0);
  const [timeLeft, setTimeLeft] = useState({
    hours: 23,
    minutes: 59,
    seconds: 59,
  });

  useEffect(() => {
    const timer = setInterval(() => {
      setTimeLeft((prev) => {
        if (prev.seconds > 0) {
          return { ...prev, seconds: prev.seconds - 1 };
        } else if (prev.minutes > 0) {
          return { ...prev, minutes: prev.minutes - 1, seconds: 59 };
        } else if (prev.hours > 0) {
          return { hours: prev.hours - 1, minutes: 59, seconds: 59 };
        }
        return { hours: 23, minutes: 59, seconds: 59 };
      });
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  return (
    <div className="min-h-screen bg-background">
      <Header />
      <main className="max-w-7xl mx-auto px-4 py-8">
        {/* Breadcrumb */}
        <nav className="flex items-center gap-2 text-sm text-muted-foreground mb-8">
          <Link href="/" className="hover:text-primary">
            Home
          </Link>
          <ChevronRight className="w-4 h-4" />
          <span className="text-foreground">Deals</span>
        </nav>

        {/* Hero Banner */}
        <div className="glass-bubble rounded-3xl p-8 md:p-12 mb-12 bg-gradient-to-r from-primary/30 via-accent/20 to-primary/30 relative overflow-hidden">
          <div className="absolute inset-0 overflow-hidden pointer-events-none">
            <div className="absolute -top-20 -right-20 w-64 h-64 rounded-full bg-primary/20 blur-3xl bubble-float" />
            <div
              className="absolute -bottom-20 -left-20 w-64 h-64 rounded-full bg-accent/20 blur-3xl bubble-float"
              style={{ animationDelay: "2s" }}
            />
          </div>
          <div className="relative">
            <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-6">
              <div>
                <div className="flex items-center gap-3 mb-4">
                  <div className="w-12 h-12 rounded-full bg-primary/30 flex items-center justify-center">
                    <Zap className="w-6 h-6 text-primary" />
                  </div>
                  <span className="text-sm font-medium text-primary uppercase tracking-wider">
                    Flash Sale
                  </span>
                </div>
                <h1 className="text-3xl md:text-4xl font-bold text-foreground mb-4">
                  Today's Best Deals
                </h1>
                <p className="text-muted-foreground max-w-xl">
                  Discover incredible discounts on top products. Limited time
                  offers you don't want to miss!
                </p>
              </div>

              {/* Countdown Timer */}
              <div className="flex items-center gap-4">
                <Timer className="w-6 h-6 text-primary" />
                <div className="flex gap-2">
                  <div className="glass px-4 py-3 rounded-xl text-center min-w-[60px]">
                    <div className="text-2xl font-bold text-foreground">
                      {String(timeLeft.hours).padStart(2, "0")}
                    </div>
                    <div className="text-xs text-muted-foreground uppercase">
                      Hours
                    </div>
                  </div>
                  <span className="text-2xl font-bold text-primary self-center">
                    :
                  </span>
                  <div className="glass px-4 py-3 rounded-xl text-center min-w-[60px]">
                    <div className="text-2xl font-bold text-foreground">
                      {String(timeLeft.minutes).padStart(2, "0")}
                    </div>
                    <div className="text-xs text-muted-foreground uppercase">
                      Mins
                    </div>
                  </div>
                  <span className="text-2xl font-bold text-primary self-center">
                    :
                  </span>
                  <div className="glass px-4 py-3 rounded-xl text-center min-w-[60px]">
                    <div className="text-2xl font-bold text-foreground">
                      {String(timeLeft.seconds).padStart(2, "0")}
                    </div>
                    <div className="text-xs text-muted-foreground uppercase">
                      Secs
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Flash Deals */}
        <section className="mb-12">
          <div className="flex items-center gap-3 mb-6">
            <Zap className="w-6 h-6 text-primary" />
            <h2 className="text-2xl font-bold text-foreground">
              Flash Deals - Up to 70% Off
            </h2>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {deals.map((product) => (
              <ProductCard key={product.id} product={product} />
            ))}
          </div>
        </section>

        {/* All Deals */}
        <section>
          <h2 className="text-2xl font-bold text-foreground mb-6">
            All Deals ({allDeals.length} products)
          </h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {allDeals.map((product) => (
              <ProductCard key={product.id} product={product} />
            ))}
          </div>
        </section>
      </main>
      <Footer />
    </div>
  );
}
