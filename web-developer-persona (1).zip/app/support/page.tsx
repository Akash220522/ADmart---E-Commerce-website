"use client";

import React from "react"

import { useState } from "react";
import Link from "next/link";
import { Header } from "@/components/layout/header";
import { Footer } from "@/components/layout/footer";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import {
  Phone,
  Mail,
  MessageSquare,
  MapPin,
  Clock,
  ChevronDown,
  Search,
  Package,
  CreditCard,
  Truck,
  RotateCcw,
  ShieldCheck,
  HelpCircle,
} from "lucide-react";

const faqs = [
  {
    category: "Orders",
    icon: Package,
    questions: [
      {
        q: "How do I track my order?",
        a: "You can track your order by going to 'My Orders' in your account or use the tracking number sent to your email. Visit our Track Order page and enter your order ID.",
      },
      {
        q: "Can I modify my order after placing it?",
        a: "You can modify your order within 1 hour of placing it. After that, please contact our support team for assistance.",
      },
      {
        q: "What is the delivery time?",
        a: "Standard delivery takes 3-7 business days. Express delivery is available for select locations with 1-2 day delivery.",
      },
    ],
  },
  {
    category: "Payments",
    icon: CreditCard,
    questions: [
      {
        q: "What payment methods are accepted?",
        a: "We accept Credit/Debit Cards, UPI, Net Banking, Wallets, and Cash on Delivery (COD) for orders under Rs. 50,000.",
      },
      {
        q: "Is my payment information secure?",
        a: "Yes, all transactions are encrypted with 256-bit SSL security. We never store your complete card details.",
      },
      {
        q: "When will I be charged?",
        a: "Your card will be charged immediately upon order confirmation. For COD orders, payment is collected at delivery.",
      },
    ],
  },
  {
    category: "Returns & Refunds",
    icon: RotateCcw,
    questions: [
      {
        q: "What is your return policy?",
        a: "We offer a 7-day return policy for most products. Electronics have a 7-day replacement guarantee. Fashion items can be returned within 30 days.",
      },
      {
        q: "How long does it take to process a refund?",
        a: "Refunds are processed within 5-7 business days after we receive the returned item. The amount will be credited to your original payment method.",
      },
      {
        q: "How do I initiate a return?",
        a: "Go to My Orders, select the item you want to return, and click 'Return Item'. Schedule a pickup or drop it off at our partner locations.",
      },
    ],
  },
];

const contactMethods = [
  {
    icon: Phone,
    title: "Phone Support",
    description: "Talk to our support team",
    value: "1800-123-4567",
    subtext: "Toll-free, 24/7 available",
  },
  {
    icon: Mail,
    title: "Email Support",
    description: "Send us an email",
    value: "support@admart.com",
    subtext: "Response within 24 hours",
  },
  {
    icon: MessageSquare,
    title: "Live Chat",
    description: "Chat with us instantly",
    value: "Start Chat",
    subtext: "Available 9 AM - 9 PM",
    isButton: true,
  },
];

export default function SupportPage() {
  const [searchQuery, setSearchQuery] = useState("");
  const [expandedFaq, setExpandedFaq] = useState<string | null>(null);
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone: "",
    orderId: "",
    subject: "",
    message: "",
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    alert("Your message has been sent! We will get back to you within 24 hours.");
    setFormData({ name: "", email: "", phone: "", orderId: "", subject: "", message: "" });
  };

  return (
    <div className="min-h-screen bg-background">
      <Header />
      <main className="container mx-auto px-4 py-8">
        {/* Hero Section */}
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold mb-4">How can we help you?</h1>
          <p className="text-muted-foreground max-w-2xl mx-auto mb-8">
            Find answers to your questions or get in touch with our support team
          </p>
          <div className="max-w-xl mx-auto relative">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
            <Input
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search for help..."
              className="pl-12 h-14 text-lg glass-card"
            />
          </div>
        </div>

        {/* Quick Links */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-12">
          {[
            { icon: Package, label: "Track Order", href: "/track-order" },
            { icon: RotateCcw, label: "Returns", href: "/refund" },
            { icon: Truck, label: "Shipping", href: "#shipping" },
            { icon: ShieldCheck, label: "Warranty", href: "#warranty" },
          ].map((item) => (
            <Link key={item.label} href={item.href}>
              <div className="glass-bubble rounded-2xl p-6 text-center hover:glow-purple transition-all cursor-pointer">
                <item.icon className="w-8 h-8 mx-auto mb-3 text-primary" />
                <p className="font-medium">{item.label}</p>
              </div>
            </Link>
          ))}
        </div>

        <div className="grid lg:grid-cols-3 gap-8">
          {/* FAQs */}
          <div className="lg:col-span-2">
            <h2 className="text-2xl font-bold mb-6">Frequently Asked Questions</h2>
            <div className="space-y-6">
              {faqs.map((category) => (
                <div key={category.category} className="glass-bubble rounded-2xl p-6">
                  <div className="flex items-center gap-3 mb-4">
                    <category.icon className="w-6 h-6 text-primary" />
                    <h3 className="text-lg font-semibold">{category.category}</h3>
                  </div>
                  <div className="space-y-3">
                    {category.questions.map((faq, idx) => {
                      const faqId = `${category.category}-${idx}`;
                      return (
                        <div key={faqId} className="border-b border-border last:border-0 pb-3 last:pb-0">
                          <button
                            onClick={() => setExpandedFaq(expandedFaq === faqId ? null : faqId)}
                            className="w-full flex items-center justify-between text-left py-2"
                          >
                            <span className="font-medium">{faq.q}</span>
                            <ChevronDown
                              className={`w-5 h-5 text-muted-foreground transition-transform ${
                                expandedFaq === faqId ? "rotate-180" : ""
                              }`}
                            />
                          </button>
                          {expandedFaq === faqId && (
                            <p className="text-muted-foreground text-sm pb-2">{faq.a}</p>
                          )}
                        </div>
                      );
                    })}
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Contact Info */}
          <div className="space-y-6">
            <h2 className="text-2xl font-bold">Contact Us</h2>
            {contactMethods.map((method) => (
              <div key={method.title} className="glass-card rounded-2xl p-6">
                <div className="flex items-start gap-4">
                  <div className="p-3 rounded-xl bg-primary/20">
                    <method.icon className="w-6 h-6 text-primary" />
                  </div>
                  <div className="flex-1">
                    <h3 className="font-semibold">{method.title}</h3>
                    <p className="text-sm text-muted-foreground">{method.description}</p>
                    {method.isButton ? (
                      <Button className="mt-3 bg-primary hover:bg-primary/90">{method.value}</Button>
                    ) : (
                      <p className="text-primary font-semibold mt-2">{method.value}</p>
                    )}
                    <p className="text-xs text-muted-foreground mt-1">{method.subtext}</p>
                  </div>
                </div>
              </div>
            ))}

            {/* Office Info */}
            <div className="glass-card rounded-2xl p-6">
              <h3 className="font-semibold mb-4 flex items-center gap-2">
                <MapPin className="w-5 h-5 text-primary" />
                Head Office
              </h3>
              <p className="text-sm text-muted-foreground">
                ADmart Technologies Pvt. Ltd.<br />
                123, Tech Park, Electronic City<br />
                Bangalore, Karnataka - 560100
              </p>
              <div className="flex items-center gap-2 mt-4 text-sm text-muted-foreground">
                <Clock className="w-4 h-4" />
                <span>Mon - Sat: 9:00 AM - 6:00 PM</span>
              </div>
            </div>
          </div>
        </div>

        {/* Contact Form */}
        <div className="mt-12">
          <div className="glass-bubble rounded-3xl p-8 max-w-3xl mx-auto">
            <div className="text-center mb-8">
              <HelpCircle className="w-12 h-12 mx-auto mb-4 text-primary" />
              <h2 className="text-2xl font-bold">Still need help?</h2>
              <p className="text-muted-foreground">Fill out the form below and we will get back to you</p>
            </div>

            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="grid md:grid-cols-2 gap-6">
                <div>
                  <Label>Full Name</Label>
                  <Input
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    placeholder="Enter your name"
                    className="mt-1"
                    required
                  />
                </div>
                <div>
                  <Label>Email Address</Label>
                  <Input
                    type="email"
                    value={formData.email}
                    onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                    placeholder="Enter your email"
                    className="mt-1"
                    required
                  />
                </div>
                <div>
                  <Label>Phone Number</Label>
                  <Input
                    value={formData.phone}
                    onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                    placeholder="Enter phone number"
                    className="mt-1"
                  />
                </div>
                <div>
                  <Label>Order ID (Optional)</Label>
                  <Input
                    value={formData.orderId}
                    onChange={(e) => setFormData({ ...formData, orderId: e.target.value })}
                    placeholder="ADM1234567890"
                    className="mt-1"
                  />
                </div>
              </div>
              <div>
                <Label>Subject</Label>
                <Input
                  value={formData.subject}
                  onChange={(e) => setFormData({ ...formData, subject: e.target.value })}
                  placeholder="What is your query about?"
                  className="mt-1"
                  required
                />
              </div>
              <div>
                <Label>Message</Label>
                <Textarea
                  value={formData.message}
                  onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                  placeholder="Describe your issue in detail..."
                  className="mt-1 min-h-[150px]"
                  required
                />
              </div>
              <Button type="submit" className="w-full h-12 bg-primary hover:bg-primary/90">
                Submit Request
              </Button>
            </form>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
}
