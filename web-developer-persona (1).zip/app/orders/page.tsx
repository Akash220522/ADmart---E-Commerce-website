"use client";

import { useState } from "react";
import Link from "next/link";
import Image from "next/image";
import { Header } from "@/components/layout/header";
import { Footer } from "@/components/layout/footer";
import { Button } from "@/components/ui/button";
import { useStore } from "@/context/store-context";
import {
  Package,
  Truck,
  CheckCircle,
  Clock,
  MapPin,
  ChevronRight,
  RotateCcw,
  Star,
  Download,
} from "lucide-react";

const sampleOrders = [
  {
    id: "ADM1706234567",
    date: "Jan 25, 2026",
    status: "delivered",
    items: [
      {
        id: 1,
        name: "Apple iPhone 15 Pro Max",
        image: "https://images.unsplash.com/photo-1695048133142-1a20484d2569?w=100&h=100&fit=crop",
        price: 134900,
        quantity: 1,
      },
    ],
    total: 134900,
    deliveredDate: "Jan 28, 2026",
  },
  {
    id: "ADM1706234568",
    date: "Jan 20, 2026",
    status: "shipped",
    items: [
      {
        id: 2,
        name: "Sony WH-1000XM5 Headphones",
        image: "https://images.unsplash.com/photo-1618366712010-f4ae9c647dcb?w=100&h=100&fit=crop",
        price: 29990,
        quantity: 1,
      },
      {
        id: 3,
        name: "Apple AirPods Pro 2nd Gen",
        image: "https://images.unsplash.com/photo-1600294037681-c80b4cb5b434?w=100&h=100&fit=crop",
        price: 24900,
        quantity: 1,
      },
    ],
    total: 54890,
    expectedDelivery: "Jan 31, 2026",
  },
  {
    id: "ADM1706234569",
    date: "Jan 15, 2026",
    status: "processing",
    items: [
      {
        id: 4,
        name: "Samsung 55\" QLED 4K Smart TV",
        image: "https://images.unsplash.com/photo-1593359677879-a4bb92f829d1?w=100&h=100&fit=crop",
        price: 74990,
        quantity: 1,
      },
    ],
    total: 74990,
    expectedDelivery: "Feb 2, 2026",
  },
];

const statusConfig = {
  processing: { icon: Clock, color: "text-yellow-500", bg: "bg-yellow-500/10", label: "Processing" },
  shipped: { icon: Truck, color: "text-blue-500", bg: "bg-blue-500/10", label: "Shipped" },
  delivered: { icon: CheckCircle, color: "text-green-500", bg: "bg-green-500/10", label: "Delivered" },
  cancelled: { icon: RotateCcw, color: "text-red-500", bg: "bg-red-500/10", label: "Cancelled" },
};

export default function OrdersPage() {
  const { isAuthenticated } = useStore();
  const [filter, setFilter] = useState("all");

  const filteredOrders = filter === "all" 
    ? sampleOrders 
    : sampleOrders.filter(order => order.status === filter);

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-background">
        <Header />
        <main className="container mx-auto px-4 py-20">
          <div className="glass-bubble rounded-3xl p-12 text-center max-w-md mx-auto">
            <Package className="w-16 h-16 mx-auto mb-4 text-primary" />
            <h1 className="text-2xl font-bold mb-4">Track Your Orders</h1>
            <p className="text-muted-foreground mb-6">
              Sign in to view your order history and track deliveries
            </p>
            <Link href="/signin">
              <Button className="w-full bg-primary hover:bg-primary/90">Sign In</Button>
            </Link>
          </div>
        </main>
        <Footer />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <Header />
      <main className="container mx-auto px-4 py-8">
        <div className="flex flex-col md:flex-row md:items-center justify-between mb-8 gap-4">
          <h1 className="text-3xl font-bold">My Orders</h1>
          <div className="flex gap-2 flex-wrap">
            {["all", "processing", "shipped", "delivered"].map((status) => (
              <button
                key={status}
                onClick={() => setFilter(status)}
                className={`px-4 py-2 rounded-full text-sm capitalize transition-all ${
                  filter === status
                    ? "bg-primary text-primary-foreground"
                    : "glass-card hover:bg-secondary"
                }`}
              >
                {status === "all" ? "All Orders" : status}
              </button>
            ))}
          </div>
        </div>

        {filteredOrders.length === 0 ? (
          <div className="glass-bubble rounded-3xl p-12 text-center">
            <Package className="w-16 h-16 mx-auto mb-4 text-muted-foreground" />
            <h2 className="text-xl font-semibold mb-2">No orders found</h2>
            <p className="text-muted-foreground mb-6">
              {filter === "all" 
                ? "You haven't placed any orders yet" 
                : `No ${filter} orders found`}
            </p>
            <Link href="/">
              <Button className="bg-primary hover:bg-primary/90">Start Shopping</Button>
            </Link>
          </div>
        ) : (
          <div className="space-y-6">
            {filteredOrders.map((order) => {
              const StatusIcon = statusConfig[order.status as keyof typeof statusConfig].icon;
              const statusData = statusConfig[order.status as keyof typeof statusConfig];

              return (
                <div key={order.id} className="glass-bubble rounded-2xl overflow-hidden">
                  {/* Order Header */}
                  <div className="p-6 border-b border-border flex flex-col md:flex-row md:items-center justify-between gap-4">
                    <div className="flex items-center gap-4">
                      <div className={`p-3 rounded-xl ${statusData.bg}`}>
                        <StatusIcon className={`w-6 h-6 ${statusData.color}`} />
                      </div>
                      <div>
                        <p className="text-sm text-muted-foreground">Order ID: {order.id}</p>
                        <p className="font-semibold">{statusData.label}</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-4 text-sm">
                      <div>
                        <p className="text-muted-foreground">Ordered on</p>
                        <p className="font-medium">{order.date}</p>
                      </div>
                      {order.status === "delivered" ? (
                        <div>
                          <p className="text-muted-foreground">Delivered on</p>
                          <p className="font-medium text-green-500">{order.deliveredDate}</p>
                        </div>
                      ) : (
                        <div>
                          <p className="text-muted-foreground">Expected by</p>
                          <p className="font-medium text-primary">{order.expectedDelivery}</p>
                        </div>
                      )}
                    </div>
                  </div>

                  {/* Order Items */}
                  <div className="p-6">
                    {order.items.map((item, idx) => (
                      <div key={item.id} className={`flex gap-4 ${idx > 0 ? "mt-4 pt-4 border-t border-border" : ""}`}>
                        <div className="relative w-20 h-20 rounded-xl overflow-hidden flex-shrink-0 glass-card">
                          <Image
                            src={item.image || "/placeholder.svg"}
                            alt={item.name}
                            fill
                            className="object-cover"
                          />
                        </div>
                        <div className="flex-1">
                          <h3 className="font-medium">{item.name}</h3>
                          <p className="text-sm text-muted-foreground">Qty: {item.quantity}</p>
                          <p className="font-semibold text-primary mt-1">
                            Rs. {item.price.toLocaleString("en-IN")}
                          </p>
                        </div>
                        <div className="flex flex-col gap-2">
                          {order.status === "delivered" && (
                            <>
                              <Button variant="outline" size="sm" className="gap-2 bg-transparent">
                                <Star className="w-4 h-4" />
                                Rate
                              </Button>
                              <Button variant="outline" size="sm" className="gap-2 bg-transparent">
                                <RotateCcw className="w-4 h-4" />
                                Return
                              </Button>
                            </>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>

                  {/* Order Footer */}
                  <div className="p-6 border-t border-border bg-secondary/20 flex flex-col md:flex-row md:items-center justify-between gap-4">
                    <div className="flex items-center gap-6">
                      <div>
                        <p className="text-sm text-muted-foreground">Total Amount</p>
                        <p className="text-xl font-bold text-gradient">
                          Rs. {order.total.toLocaleString("en-IN")}
                        </p>
                      </div>
                    </div>
                    <div className="flex gap-3">
                      <Link href={`/track-order?id=${order.id}`}>
                        <Button variant="outline" className="gap-2 bg-transparent">
                          <MapPin className="w-4 h-4" />
                          Track Order
                        </Button>
                      </Link>
                      <Button variant="outline" className="gap-2 bg-transparent">
                        <Download className="w-4 h-4" />
                        Invoice
                      </Button>
                      <Link href={`/orders/${order.id}`}>
                        <Button className="gap-2 bg-primary hover:bg-primary/90">
                          View Details
                          <ChevronRight className="w-4 h-4" />
                        </Button>
                      </Link>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </main>
      <Footer />
    </div>
  );
}
