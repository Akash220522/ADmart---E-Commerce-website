"use client";

import React from "react"

import Image from "next/image";
import Link from "next/link";
import { Heart, ShoppingCart, Star } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useStore, type Product } from "@/context/store-context";
import { useToast } from "@/hooks/use-toast";
import { cn } from "@/lib/utils";

interface ProductCardProps {
  product: Product;
  featured?: boolean;
}

export function ProductCard({ product, featured = false }: ProductCardProps) {
  const { addToCart, addToWishlist, removeFromWishlist, isInWishlist } =
    useStore();
  const { toast } = useToast();
  const inWishlist = isInWishlist(product.id);

  const handleAddToCart = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    addToCart(product);
    toast({
      title: "Added to Cart",
      description: `${product.name} has been added to your cart.`,
    });
  };

  const handleWishlist = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (inWishlist) {
      removeFromWishlist(product.id);
      toast({
        title: "Removed from Wishlist",
        description: `${product.name} has been removed from your wishlist.`,
      });
    } else {
      addToWishlist(product);
      toast({
        title: "Added to Wishlist",
        description: `${product.name} has been added to your wishlist.`,
      });
    }
  };

  return (
    <Link href={`/product/${product.id}`}>
      <div
        className={cn(
          "group glass-bubble rounded-2xl overflow-hidden transition-all duration-300 hover:scale-[1.02] hover:glow-purple bubble-float",
          featured && "md:col-span-2 md:row-span-2"
        )}
        style={{ animationDelay: `${Math.random() * 2}s` }}
      >
        {/* Image Container */}
        <div
          className={cn(
            "relative overflow-hidden bg-muted/20",
            featured ? "h-64 md:h-80" : "h-48"
          )}
        >
          <Image
            src={product.image || "/placeholder.svg"}
            alt={product.name}
            fill
            className="object-cover transition-transform duration-500 group-hover:scale-110"
            sizes={featured ? "(max-width: 768px) 100vw, 50vw" : "(max-width: 640px) 100vw, (max-width: 1024px) 50vw, 25vw"}
          />

          {/* Badges */}
          <div className="absolute top-3 left-3 flex flex-col gap-2">
            {product.discount && (
              <span className="px-2 py-1 rounded-full bg-primary text-primary-foreground text-xs font-semibold">
                {product.discount}% OFF
              </span>
            )}
            {product.badge && (
              <span className="px-2 py-1 rounded-full bg-accent text-accent-foreground text-xs font-semibold">
                {product.badge}
              </span>
            )}
          </div>

          {/* Wishlist Button */}
          <button
            type="button"
            onClick={handleWishlist}
            className={cn(
              "absolute top-3 right-3 w-9 h-9 rounded-full glass flex items-center justify-center transition-all",
              inWishlist
                ? "bg-primary/20 text-primary"
                : "text-muted-foreground hover:text-primary"
            )}
            aria-label={inWishlist ? "Remove from wishlist" : "Add to wishlist"}
          >
            <Heart
              className={cn("w-5 h-5", inWishlist && "fill-current")}
            />
          </button>

          {/* Quick Add Button */}
          <div className="absolute bottom-3 left-3 right-3 opacity-0 group-hover:opacity-100 transition-opacity">
            <Button
              onClick={handleAddToCart}
              className="w-full bg-primary hover:bg-primary/80 text-primary-foreground gap-2"
              size="sm"
            >
              <ShoppingCart className="w-4 h-4" />
              Add to Cart
            </Button>
          </div>
        </div>

        {/* Content */}
        <div className="p-4">
          <div className="text-xs text-muted-foreground uppercase tracking-wider mb-1">
            {product.category}
          </div>
          <h3 className="font-medium text-foreground line-clamp-2 mb-2 group-hover:text-primary transition-colors">
            {product.name}
          </h3>

          {/* Rating */}
          <div className="flex items-center gap-2 mb-3">
            <div className="flex items-center gap-1 px-2 py-0.5 rounded-full bg-primary/20">
              <Star className="w-3 h-3 fill-primary text-primary" />
              <span className="text-xs font-medium text-primary">
                {product.rating}
              </span>
            </div>
            <span className="text-xs text-muted-foreground">
              ({product.reviews.toLocaleString()} reviews)
            </span>
          </div>

          {/* Price */}
          <div className="flex items-baseline gap-2">
            <span className="text-lg font-bold text-foreground">
              Rs.{product.price.toLocaleString()}
            </span>
            {product.originalPrice && (
              <>
                <span className="text-sm text-muted-foreground line-through">
                  Rs.{product.originalPrice.toLocaleString()}
                </span>
              </>
            )}
          </div>

          {/* Stock */}
          {product.stock < 10 && (
            <p className="text-xs text-destructive mt-2">
              Only {product.stock} left in stock!
            </p>
          )}
        </div>
      </div>
    </Link>
  );
}
