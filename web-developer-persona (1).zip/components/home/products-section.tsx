"use client";

import Link from "next/link";
import { ArrowRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import { ProductCard } from "@/components/product/product-card";
import { products, getTopRated } from "@/lib/products";

export function ProductsSection() {
  const topRated = getTopRated();
  const featured = products.slice(0, 8);

  return (
    <>
      {/* Top Rated Section */}
      <section className="py-12">
        <div className="max-w-7xl mx-auto px-4">
          <div className="flex items-center justify-between mb-8">
            <div>
              <h2 className="text-2xl md:text-3xl font-bold text-foreground">
                Top Rated Products
              </h2>
              <p className="text-muted-foreground mt-1">
                Highly rated by our customers
              </p>
            </div>
            <Link href="/deals" className="hidden sm:block">
              <Button
                variant="ghost"
                className="text-primary hover:text-primary/80 gap-2"
              >
                See More <ArrowRight className="w-4 h-4" />
              </Button>
            </Link>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {topRated.map((product) => (
              <ProductCard key={product.id} product={product} />
            ))}
          </div>
        </div>
      </section>

      {/* Banner */}
      <section className="py-8">
        <div className="max-w-7xl mx-auto px-4">
          <div className="glass-bubble rounded-3xl p-8 md:p-12 bg-gradient-to-r from-primary/30 via-accent/20 to-primary/30 relative overflow-hidden">
            <div className="absolute inset-0 overflow-hidden pointer-events-none">
              <div className="absolute -top-20 -right-20 w-64 h-64 rounded-full bg-primary/20 blur-3xl" />
              <div className="absolute -bottom-20 -left-20 w-64 h-64 rounded-full bg-accent/20 blur-3xl" />
            </div>
            <div className="relative text-center">
              <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">
                Get Extra 20% Off
              </h2>
              <p className="text-lg text-muted-foreground mb-6 max-w-xl mx-auto">
                Sign up for our newsletter and get an exclusive 20% discount on
                your first purchase. Plus, be the first to know about new
                arrivals and special offers!
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center max-w-md mx-auto">
                <input
                  type="email"
                  placeholder="Enter your email"
                  className="flex-1 px-4 py-3 rounded-lg glass border-primary/30 focus:border-primary text-foreground placeholder:text-muted-foreground outline-none"
                />
                <Button className="bg-primary hover:bg-primary/80 text-primary-foreground px-8">
                  Subscribe
                </Button>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Featured Products */}
      <section className="py-12">
        <div className="max-w-7xl mx-auto px-4">
          <div className="flex items-center justify-between mb-8">
            <div>
              <h2 className="text-2xl md:text-3xl font-bold text-foreground">
                Featured Products
              </h2>
              <p className="text-muted-foreground mt-1">
                Handpicked products just for you
              </p>
            </div>
            <Link href="/category/electronics" className="hidden sm:block">
              <Button
                variant="ghost"
                className="text-primary hover:text-primary/80 gap-2"
              >
                View All <ArrowRight className="w-4 h-4" />
              </Button>
            </Link>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {featured.map((product, index) => (
              <ProductCard
                key={product.id}
                product={product}
                featured={index === 0}
              />
            ))}
          </div>
        </div>
      </section>
    </>
  );
}
