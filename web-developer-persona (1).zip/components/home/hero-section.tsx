"use client";

import Link from "next/link";
import { ArrowRight, Sparkles, Zap, Gift } from "lucide-react";
import { Button } from "@/components/ui/button";

export function HeroSection() {
  return (
    <section className="relative overflow-hidden py-12 md:py-20">
      {/* Background Bubbles */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-20 left-10 w-64 h-64 rounded-full bg-primary/10 blur-3xl bubble-float" />
        <div
          className="absolute bottom-20 right-10 w-96 h-96 rounded-full bg-accent/10 blur-3xl bubble-float"
          style={{ animationDelay: "2s" }}
        />
        <div
          className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] rounded-full bg-primary/5 blur-3xl"
        />
      </div>

      <div className="max-w-7xl mx-auto px-4 relative">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          {/* Content */}
          <div className="text-center lg:text-left">
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full glass-bubble mb-6">
              <Sparkles className="w-4 h-4 text-primary" />
              <span className="text-sm font-medium text-foreground">
                Welcome to the Future of Shopping
              </span>
            </div>

            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold mb-6 leading-tight">
              <span className="text-foreground">Shop Smart,</span>
              <br />
              <span className="text-gradient">Live Better</span>
            </h1>

            <p className="text-lg text-muted-foreground mb-8 max-w-xl mx-auto lg:mx-0">
              Discover millions of products at unbeatable prices. From
              electronics to fashion, we have got everything you need delivered
              right to your doorstep.
            </p>

            <div className="flex flex-col sm:flex-row gap-4 justify-center lg:justify-start">
              <Link href="/deals">
                <Button
                  size="lg"
                  className="w-full sm:w-auto bg-primary hover:bg-primary/80 text-primary-foreground gap-2 glow-purple"
                >
                  Explore Deals
                  <ArrowRight className="w-4 h-4" />
                </Button>
              </Link>
              <Link href="/category/electronics">
                <Button
                  size="lg"
                  variant="outline"
                  className="w-full sm:w-auto border-primary/50 text-foreground hover:bg-primary/10 bg-transparent"
                >
                  Shop Electronics
                </Button>
              </Link>
            </div>

            {/* Stats */}
            <div className="grid grid-cols-3 gap-6 mt-12 pt-8 border-t border-primary/20">
              <div>
                <div className="text-2xl md:text-3xl font-bold text-gradient">10K+</div>
                <div className="text-sm text-muted-foreground">Products</div>
              </div>
              <div>
                <div className="text-2xl md:text-3xl font-bold text-gradient">50K+</div>
                <div className="text-sm text-muted-foreground">Happy Customers</div>
              </div>
              <div>
                <div className="text-2xl md:text-3xl font-bold text-gradient">99%</div>
                <div className="text-sm text-muted-foreground">Satisfaction</div>
              </div>
            </div>
          </div>

          {/* Featured Cards */}
          <div className="relative hidden lg:block">
            <div className="grid grid-cols-2 gap-4">
              {/* Deal Card */}
              <Link
                href="/deals"
                className="glass-bubble p-6 rounded-2xl hover:scale-105 transition-transform bubble-float"
              >
                <div className="w-12 h-12 rounded-full bg-primary/20 flex items-center justify-center mb-4">
                  <Zap className="w-6 h-6 text-primary" />
                </div>
                <h3 className="font-semibold text-foreground mb-2">Flash Deals</h3>
                <p className="text-sm text-muted-foreground mb-4">
                  Up to 70% off on top brands
                </p>
                <span className="text-primary text-sm font-medium flex items-center gap-1">
                  Shop Now <ArrowRight className="w-4 h-4" />
                </span>
              </Link>

              {/* New Arrivals Card */}
              <Link
                href="/category/fashion"
                className="glass-bubble p-6 rounded-2xl hover:scale-105 transition-transform bubble-float mt-8"
                style={{ animationDelay: "1s" }}
              >
                <div className="w-12 h-12 rounded-full bg-accent/20 flex items-center justify-center mb-4">
                  <Gift className="w-6 h-6 text-accent" />
                </div>
                <h3 className="font-semibold text-foreground mb-2">New Arrivals</h3>
                <p className="text-sm text-muted-foreground mb-4">
                  Fresh styles just landed
                </p>
                <span className="text-accent text-sm font-medium flex items-center gap-1">
                  Discover <ArrowRight className="w-4 h-4" />
                </span>
              </Link>

              {/* Promo Card */}
              <div
                className="col-span-2 glass-bubble p-6 rounded-2xl bg-gradient-to-r from-primary/20 to-accent/20 bubble-float"
                style={{ animationDelay: "0.5s" }}
              >
                <div className="flex items-center justify-between">
                  <div>
                    <div className="text-xs text-muted-foreground uppercase tracking-wider mb-1">
                      Limited Time Offer
                    </div>
                    <div className="text-2xl font-bold text-foreground mb-2">
                      Get Rs.500 Off
                    </div>
                    <p className="text-sm text-muted-foreground">
                      On your first order above Rs.2000
                    </p>
                  </div>
                  <div className="text-right">
                    <div className="text-xs text-muted-foreground mb-1">Use Code</div>
                    <div className="px-4 py-2 rounded-lg bg-primary/30 text-primary font-bold">
                      FIRST20
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
