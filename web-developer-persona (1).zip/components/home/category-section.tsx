"use client";

import React from "react"

import Link from "next/link";
import {
  Laptop,
  Shirt,
  Home,
  Sparkles,
  Dumbbell,
  BookOpen,
  Gamepad2,
  ShoppingBasket,
} from "lucide-react";
import { categories } from "@/lib/products";

const iconMap: Record<string, React.ComponentType<{ className?: string }>> = {
  Laptop,
  Shirt,
  Home,
  Sparkles,
  Dumbbell,
  BookOpen,
  Gamepad2,
  ShoppingBasket,
};

export function CategorySection() {
  return (
    <section className="py-12">
      <div className="max-w-7xl mx-auto px-4">
        <div className="flex items-center justify-between mb-8">
          <div>
            <h2 className="text-2xl md:text-3xl font-bold text-foreground">
              Shop by Category
            </h2>
            <p className="text-muted-foreground mt-1">
              Find what you need in our curated collections
            </p>
          </div>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-8 gap-4">
          {categories.map((category, index) => {
            const Icon = iconMap[category.icon] || Laptop;
            return (
              <Link
                key={category.id}
                href={`/category/${category.id}`}
                className="group"
              >
                <div
                  className="glass-bubble p-4 rounded-2xl flex flex-col items-center text-center hover:scale-105 transition-all duration-300 hover:glow-purple bubble-float"
                  style={{ animationDelay: `${index * 0.1}s` }}
                >
                  <div className="w-14 h-14 rounded-full bg-primary/20 flex items-center justify-center mb-3 group-hover:bg-primary/30 transition-colors">
                    <Icon className="w-7 h-7 text-primary" />
                  </div>
                  <span className="text-sm font-medium text-foreground group-hover:text-primary transition-colors">
                    {category.name}
                  </span>
                </div>
              </Link>
            );
          })}
        </div>
      </div>
    </section>
  );
}
