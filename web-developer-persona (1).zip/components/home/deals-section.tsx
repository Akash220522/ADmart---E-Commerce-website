"use client";

import Link from "next/link";
import { ArrowRight, Timer } from "lucide-react";
import { Button } from "@/components/ui/button";
import { ProductCard } from "@/components/product/product-card";
import { getDeals } from "@/lib/products";
import { useEffect, useState } from "react";

export function DealsSection() {
  const deals = getDeals().slice(0, 4);
  const [timeLeft, setTimeLeft] = useState({
    hours: 23,
    minutes: 59,
    seconds: 59,
  });

  useEffect(() => {
    const timer = setInterval(() => {
      setTimeLeft((prev) => {
        if (prev.seconds > 0) {
          return { ...prev, seconds: prev.seconds - 1 };
        } else if (prev.minutes > 0) {
          return { ...prev, minutes: prev.minutes - 1, seconds: 59 };
        } else if (prev.hours > 0) {
          return { hours: prev.hours - 1, minutes: 59, seconds: 59 };
        }
        return { hours: 23, minutes: 59, seconds: 59 };
      });
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  return (
    <section className="py-12">
      <div className="max-w-7xl mx-auto px-4">
        <div className="glass-bubble rounded-3xl p-6 md:p-8">
          {/* Header */}
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 mb-8">
            <div>
              <div className="flex items-center gap-3 mb-2">
                <h2 className="text-2xl md:text-3xl font-bold text-gradient">
                  Deal of the Day
                </h2>
                <span className="px-3 py-1 rounded-full bg-primary/20 text-primary text-sm font-medium">
                  Up to 70% Off
                </span>
              </div>
              <p className="text-muted-foreground">
                Grab these deals before they are gone!
              </p>
            </div>

            <div className="flex items-center gap-4">
              {/* Countdown Timer */}
              <div className="flex items-center gap-2">
                <Timer className="w-5 h-5 text-primary" />
                <div className="flex gap-1">
                  <div className="glass px-3 py-2 rounded-lg text-center min-w-[50px]">
                    <div className="text-lg font-bold text-foreground">
                      {String(timeLeft.hours).padStart(2, "0")}
                    </div>
                    <div className="text-[10px] text-muted-foreground uppercase">
                      Hrs
                    </div>
                  </div>
                  <span className="text-xl font-bold text-primary self-center">:</span>
                  <div className="glass px-3 py-2 rounded-lg text-center min-w-[50px]">
                    <div className="text-lg font-bold text-foreground">
                      {String(timeLeft.minutes).padStart(2, "0")}
                    </div>
                    <div className="text-[10px] text-muted-foreground uppercase">
                      Min
                    </div>
                  </div>
                  <span className="text-xl font-bold text-primary self-center">:</span>
                  <div className="glass px-3 py-2 rounded-lg text-center min-w-[50px]">
                    <div className="text-lg font-bold text-foreground">
                      {String(timeLeft.seconds).padStart(2, "0")}
                    </div>
                    <div className="text-[10px] text-muted-foreground uppercase">
                      Sec
                    </div>
                  </div>
                </div>
              </div>

              <Link href="/deals" className="hidden sm:block">
                <Button
                  variant="outline"
                  className="border-primary/50 text-foreground hover:bg-primary/10 gap-2 bg-transparent"
                >
                  View All <ArrowRight className="w-4 h-4" />
                </Button>
              </Link>
            </div>
          </div>

          {/* Products Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {deals.map((product) => (
              <ProductCard key={product.id} product={product} />
            ))}
          </div>

          {/* Mobile View All */}
          <div className="mt-6 sm:hidden">
            <Link href="/deals">
              <Button className="w-full bg-primary hover:bg-primary/80 text-primary-foreground gap-2">
                View All Deals <ArrowRight className="w-4 h-4" />
              </Button>
            </Link>
          </div>
        </div>
      </div>
    </section>
  );
}
