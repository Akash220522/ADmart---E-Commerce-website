"use client";

import React from "react"

import Link from "next/link";
import { useState } from "react";
import {
  Search,
  ShoppingCart,
  User,
  Heart,
  Menu,
  X,
  MapPin,
  ChevronDown,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
  DropdownMenuSeparator,
} from "@/components/ui/dropdown-menu";
import { useStore } from "@/context/store-context";
import { categories } from "@/lib/products";
import { useRouter } from "next/navigation";

export function Header() {
  const { cartCount, user, setUser, wishlist } = useStore();
  const [searchQuery, setSearchQuery] = useState("");
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const router = useRouter();

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      router.push(`/search?q=${encodeURIComponent(searchQuery.trim())}`);
    }
  };

  const handleLogout = () => {
    setUser(null);
    router.push("/");
  };

  return (
    <header className="sticky top-0 z-50 w-full">
      {/* Top Bar */}
      <div className="bg-primary/90 backdrop-blur-sm text-primary-foreground py-1.5 px-4 text-sm">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-4">
            <span className="hidden sm:inline">Welcome to ADmart!</span>
            <span className="text-xs sm:text-sm font-medium">
              Use code FIRST20 for 20% off
            </span>
          </div>
          <div className="flex items-center gap-4">
            <Link
              href="/track-order"
              className="hover:underline hidden sm:inline"
            >
              Track Order
            </Link>
            <Link href="/support" className="hover:underline hidden sm:inline">
              Help
            </Link>
          </div>
        </div>
      </div>

      {/* Main Header */}
      <div className="glass-bubble border-t-0 border-x-0">
        <div className="max-w-7xl mx-auto px-4 py-3">
          <div className="flex items-center justify-between gap-4">
            {/* Logo */}
            <Link href="/" className="flex items-center gap-2 shrink-0">
              <div className="w-10 h-10 rounded-full bg-primary flex items-center justify-center glow-purple">
                <span className="text-primary-foreground font-bold text-lg">
                  AD
                </span>
              </div>
              <span className="text-xl sm:text-2xl font-bold text-gradient hidden sm:inline">
                ADmart
              </span>
            </Link>

            {/* Location */}
            <button
              type="button"
              className="hidden md:flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground transition-colors"
            >
              <MapPin className="w-4 h-4" />
              <div className="text-left">
                <div className="text-xs text-muted-foreground">Deliver to</div>
                <div className="font-medium text-foreground">Select Location</div>
              </div>
            </button>

            {/* Search Bar */}
            <form
              onSubmit={handleSearch}
              className="flex-1 max-w-2xl hidden md:flex"
            >
              <div className="relative w-full">
                <Input
                  type="search"
                  placeholder="Search for products, brands and more..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full pl-4 pr-12 py-2 h-11 glass-card border-primary/30 focus:border-primary text-foreground placeholder:text-muted-foreground"
                />
                <Button
                  type="submit"
                  size="sm"
                  className="absolute right-1 top-1/2 -translate-y-1/2 bg-primary hover:bg-primary/80"
                >
                  <Search className="w-4 h-4" />
                </Button>
              </div>
            </form>

            {/* Actions */}
            <div className="flex items-center gap-2 sm:gap-4">
              {/* User Menu */}
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button
                    variant="ghost"
                    className="hidden sm:flex items-center gap-2 text-foreground hover:text-primary hover:bg-primary/10"
                  >
                    <User className="w-5 h-5" />
                    <div className="text-left hidden lg:block">
                      <div className="text-xs text-muted-foreground">
                        {user ? `Hello, ${user.name.split(" ")[0]}` : "Hello, Guest"}
                      </div>
                      <div className="font-medium flex items-center gap-1">
                        Account <ChevronDown className="w-3 h-3" />
                      </div>
                    </div>
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent
                  align="end"
                  className="w-56 glass-card border-primary/30"
                >
                  {user ? (
                    <>
                      <DropdownMenuItem asChild>
                        <Link href="/profile">My Profile</Link>
                      </DropdownMenuItem>
                      <DropdownMenuItem asChild>
                        <Link href="/orders">My Orders</Link>
                      </DropdownMenuItem>
                      <DropdownMenuItem asChild>
                        <Link href="/wishlist">Wishlist</Link>
                      </DropdownMenuItem>
                      <DropdownMenuSeparator />
                      <DropdownMenuItem onClick={handleLogout}>
                        Logout
                      </DropdownMenuItem>
                    </>
                  ) : (
                    <>
                      <DropdownMenuItem asChild>
                        <Link href="/signin">Sign In</Link>
                      </DropdownMenuItem>
                      <DropdownMenuItem asChild>
                        <Link href="/signup">Create Account</Link>
                      </DropdownMenuItem>
                    </>
                  )}
                </DropdownMenuContent>
              </DropdownMenu>

              {/* Wishlist */}
              <Link href="/wishlist">
                <Button
                  variant="ghost"
                  size="icon"
                  className="relative text-foreground hover:text-primary hover:bg-primary/10"
                >
                  <Heart className="w-5 h-5" />
                  {wishlist.length > 0 && (
                    <span className="absolute -top-1 -right-1 w-5 h-5 rounded-full bg-primary text-primary-foreground text-xs flex items-center justify-center">
                      {wishlist.length}
                    </span>
                  )}
                </Button>
              </Link>

              {/* Cart */}
              <Link href="/cart">
                <Button
                  variant="ghost"
                  size="icon"
                  className="relative text-foreground hover:text-primary hover:bg-primary/10"
                >
                  <ShoppingCart className="w-5 h-5" />
                  {cartCount > 0 && (
                    <span className="absolute -top-1 -right-1 w-5 h-5 rounded-full bg-primary text-primary-foreground text-xs flex items-center justify-center">
                      {cartCount}
                    </span>
                  )}
                </Button>
              </Link>

              {/* Mobile Menu Toggle */}
              <Button
                variant="ghost"
                size="icon"
                className="md:hidden text-foreground"
                onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              >
                {mobileMenuOpen ? (
                  <X className="w-5 h-5" />
                ) : (
                  <Menu className="w-5 h-5" />
                )}
              </Button>
            </div>
          </div>

          {/* Mobile Search */}
          <form onSubmit={handleSearch} className="mt-3 md:hidden">
            <div className="relative">
              <Input
                type="search"
                placeholder="Search products..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-4 pr-12 glass-card border-primary/30 text-foreground placeholder:text-muted-foreground"
              />
              <Button
                type="submit"
                size="sm"
                className="absolute right-1 top-1/2 -translate-y-1/2 bg-primary hover:bg-primary/80"
              >
                <Search className="w-4 h-4" />
              </Button>
            </div>
          </form>
        </div>

        {/* Categories Bar */}
        <div className="border-t border-primary/20 hidden md:block">
          <div className="max-w-7xl mx-auto px-4">
            <nav className="flex items-center gap-1 py-2 overflow-x-auto">
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button
                    variant="ghost"
                    className="flex items-center gap-2 text-foreground hover:text-primary hover:bg-primary/10"
                  >
                    <Menu className="w-4 h-4" />
                    All Categories
                    <ChevronDown className="w-3 h-3" />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent className="w-56 glass-card border-primary/30">
                  {categories.map((category) => (
                    <DropdownMenuItem key={category.id} asChild>
                      <Link href={`/category/${category.id}`}>
                        {category.name}
                      </Link>
                    </DropdownMenuItem>
                  ))}
                </DropdownMenuContent>
              </DropdownMenu>

              <div className="h-4 w-px bg-border mx-2" />

              {categories.slice(0, 6).map((category) => (
                <Link
                  key={category.id}
                  href={`/category/${category.id}`}
                  className="px-3 py-1.5 text-sm text-muted-foreground hover:text-primary whitespace-nowrap transition-colors"
                >
                  {category.name}
                </Link>
              ))}

              <div className="ml-auto flex items-center gap-4">
                <Link
                  href="/deals"
                  className="text-sm font-medium text-primary hover:underline"
                >
                  Today's Deals
                </Link>
                <Link
                  href="/offers"
                  className="text-sm font-medium text-accent hover:underline"
                >
                  Offers
                </Link>
              </div>
            </nav>
          </div>
        </div>
      </div>

      {/* Mobile Menu */}
      {mobileMenuOpen && (
        <div className="md:hidden glass-card border-t border-primary/20 absolute w-full">
          <div className="p-4 space-y-4">
            {!user && (
              <div className="flex gap-2">
                <Link href="/signin" className="flex-1">
                  <Button className="w-full bg-primary hover:bg-primary/80">
                    Sign In
                  </Button>
                </Link>
                <Link href="/signup" className="flex-1">
                  <Button
                    variant="outline"
                    className="w-full border-primary/50 text-primary bg-transparent"
                  >
                    Sign Up
                  </Button>
                </Link>
              </div>
            )}

            <nav className="space-y-1">
              {categories.map((category) => (
                <Link
                  key={category.id}
                  href={`/category/${category.id}`}
                  className="block px-3 py-2 text-foreground hover:text-primary hover:bg-primary/10 rounded-lg transition-colors"
                  onClick={() => setMobileMenuOpen(false)}
                >
                  {category.name}
                </Link>
              ))}
            </nav>

            <div className="border-t border-primary/20 pt-4 space-y-2">
              <Link
                href="/deals"
                className="block px-3 py-2 font-medium text-primary"
                onClick={() => setMobileMenuOpen(false)}
              >
                Today's Deals
              </Link>
              <Link
                href="/track-order"
                className="block px-3 py-2 text-foreground"
                onClick={() => setMobileMenuOpen(false)}
              >
                Track Order
              </Link>
              <Link
                href="/support"
                className="block px-3 py-2 text-foreground"
                onClick={() => setMobileMenuOpen(false)}
              >
                Help & Support
              </Link>
            </div>
          </div>
        </div>
      )}
    </header>
  );
}
