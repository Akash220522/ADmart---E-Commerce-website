import type { Product } from "@/context/store-context";

export const categories = [
  { id: "electronics", name: "Electronics", icon: "Laptop" },
  { id: "fashion", name: "Fashion", icon: "Shirt" },
  { id: "home", name: "Home & Kitchen", icon: "Home" },
  { id: "beauty", name: "Beauty & Health", icon: "Sparkles" },
  { id: "sports", name: "Sports & Fitness", icon: "Dumbbell" },
  { id: "books", name: "Books", icon: "BookOpen" },
  { id: "toys", name: "Toys & Games", icon: "Gamepad2" },
  { id: "grocery", name: "Grocery", icon: "ShoppingBasket" },
];

export const products: Product[] = [
  // Electronics
  {
    id: "1",
    name: "Wireless Bluetooth Headphones Pro",
    description:
      "Premium noise-cancelling headphones with 40-hour battery life, deep bass, and crystal-clear audio. Perfect for music lovers and professionals.",
    price: 2999,
    originalPrice: 5999,
    image:
      "https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=400&h=400&fit=crop",
    category: "electronics",
    rating: 4.5,
    reviews: 2847,
    stock: 156,
    discount: 50,
    badge: "Best Seller",
    specifications: {
      "Battery Life": "40 Hours",
      Connectivity: "Bluetooth 5.0",
      Weight: "250g",
      Driver: "40mm",
    },
  },
  {
    id: "2",
    name: 'Smart LED TV 55" 4K Ultra HD',
    description:
      "Stunning 4K resolution with HDR10, built-in smart features, voice control, and immersive Dolby Audio.",
    price: 34999,
    originalPrice: 54999,
    image:
      "https://images.unsplash.com/photo-1593359677879-a4bb92f829d1?w=400&h=400&fit=crop",
    category: "electronics",
    rating: 4.3,
    reviews: 1523,
    stock: 45,
    discount: 36,
    badge: "Deal of the Day",
    specifications: {
      "Screen Size": '55"',
      Resolution: "4K UHD",
      "Refresh Rate": "60Hz",
      Ports: "3 HDMI, 2 USB",
    },
  },
  {
    id: "3",
    name: "Smartphone X Pro Max 256GB",
    description:
      "Flagship smartphone with 108MP camera, AMOLED display, 5G connectivity, and all-day battery.",
    price: 49999,
    originalPrice: 69999,
    image:
      "https://images.unsplash.com/photo-1511707171634-5f897ff02aa9?w=400&h=400&fit=crop",
    category: "electronics",
    rating: 4.7,
    reviews: 5621,
    stock: 89,
    discount: 29,
    badge: "Top Rated",
    specifications: {
      Storage: "256GB",
      RAM: "12GB",
      Display: '6.8" AMOLED',
      Camera: "108MP + 12MP + 8MP",
    },
  },
  {
    id: "4",
    name: "Wireless Gaming Mouse RGB",
    description:
      "High-precision gaming mouse with customizable RGB lighting, 16000 DPI sensor, and ergonomic design.",
    price: 1499,
    originalPrice: 2499,
    image:
      "https://images.unsplash.com/photo-1527864550417-7fd91fc51a46?w=400&h=400&fit=crop",
    category: "electronics",
    rating: 4.4,
    reviews: 892,
    stock: 234,
    discount: 40,
    specifications: {
      DPI: "16000",
      Buttons: "8 Programmable",
      Connectivity: "2.4GHz Wireless",
      "Battery Life": "70 Hours",
    },
  },
  {
    id: "5",
    name: "Mechanical Keyboard RGB Backlit",
    description:
      "Premium mechanical keyboard with hot-swappable switches, per-key RGB, and aluminum frame.",
    price: 3999,
    originalPrice: 5999,
    image:
      "https://images.unsplash.com/photo-1511467687858-23d96c32e4ae?w=400&h=400&fit=crop",
    category: "electronics",
    rating: 4.6,
    reviews: 1245,
    stock: 167,
    discount: 33,
    badge: "New Arrival",
    specifications: {
      "Switch Type": "Mechanical",
      Layout: "Full Size",
      Backlight: "RGB Per-Key",
      Connection: "USB-C",
    },
  },
  // Fashion
  {
    id: "6",
    name: "Men's Premium Cotton T-Shirt",
    description:
      "Soft, breathable cotton t-shirt with modern fit. Perfect for casual wear.",
    price: 499,
    originalPrice: 999,
    image:
      "https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?w=400&h=400&fit=crop",
    category: "fashion",
    rating: 4.2,
    reviews: 3456,
    stock: 500,
    discount: 50,
    specifications: {
      Material: "100% Cotton",
      Fit: "Regular",
      Care: "Machine Wash",
      Sizes: "S, M, L, XL, XXL",
    },
  },
  {
    id: "7",
    name: "Women's Designer Handbag",
    description:
      "Elegant leather handbag with multiple compartments and adjustable strap.",
    price: 2499,
    originalPrice: 4999,
    image:
      "https://images.unsplash.com/photo-1584917865442-de89df76afd3?w=400&h=400&fit=crop",
    category: "fashion",
    rating: 4.5,
    reviews: 1876,
    stock: 78,
    discount: 50,
    badge: "Trending",
    specifications: {
      Material: "Genuine Leather",
      Dimensions: '12" x 8" x 5"',
      Compartments: "3 Main + 2 Zip",
      Strap: "Adjustable",
    },
  },
  {
    id: "8",
    name: "Running Sports Shoes",
    description:
      "Lightweight running shoes with cushioned sole and breathable mesh upper.",
    price: 1999,
    originalPrice: 3499,
    image:
      "https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=400&h=400&fit=crop",
    category: "fashion",
    rating: 4.4,
    reviews: 2341,
    stock: 312,
    discount: 43,
    specifications: {
      Material: "Mesh + Rubber",
      Sole: "EVA Cushion",
      Weight: "280g",
      Sizes: "6-12 UK",
    },
  },
  {
    id: "9",
    name: "Premium Denim Jeans",
    description:
      "Classic fit denim jeans with stretch comfort and fade-resistant wash.",
    price: 1299,
    originalPrice: 2299,
    image:
      "https://images.unsplash.com/photo-1542272604-787c3835535d?w=400&h=400&fit=crop",
    category: "fashion",
    rating: 4.3,
    reviews: 1567,
    stock: 245,
    discount: 44,
    specifications: {
      Material: "98% Cotton, 2% Spandex",
      Fit: "Slim Fit",
      Rise: "Mid Rise",
      Wash: "Medium Blue",
    },
  },
  // Home & Kitchen
  {
    id: "10",
    name: "Non-Stick Cookware Set 7pc",
    description:
      "Complete cookware set with durable non-stick coating and heat-resistant handles.",
    price: 2999,
    originalPrice: 5499,
    image:
      "https://images.unsplash.com/photo-1556909114-f6e7ad7d3136?w=400&h=400&fit=crop",
    category: "home",
    rating: 4.6,
    reviews: 987,
    stock: 134,
    discount: 45,
    badge: "Value Pack",
    specifications: {
      Pieces: "7",
      Material: "Aluminum + Non-stick",
      "Dishwasher Safe": "Yes",
      Induction: "Compatible",
    },
  },
  {
    id: "11",
    name: "Air Purifier HEPA Filter",
    description:
      "Advanced air purifier with true HEPA filter, covers up to 500 sq ft.",
    price: 8999,
    originalPrice: 12999,
    image:
      "https://images.unsplash.com/photo-1585771724684-38269d6639fd?w=400&h=400&fit=crop",
    category: "home",
    rating: 4.5,
    reviews: 654,
    stock: 67,
    discount: 31,
    specifications: {
      Coverage: "500 sq ft",
      "Filter Type": "True HEPA",
      "Noise Level": "25-50 dB",
      "Filter Life": "12 months",
    },
  },
  {
    id: "12",
    name: "Automatic Coffee Maker",
    description:
      "Programmable coffee maker with built-in grinder and 12-cup capacity.",
    price: 4999,
    originalPrice: 7999,
    image:
      "https://images.unsplash.com/photo-1517668808822-9ebb02f2a0e6?w=400&h=400&fit=crop",
    category: "home",
    rating: 4.4,
    reviews: 1123,
    stock: 89,
    discount: 38,
    specifications: {
      Capacity: "12 Cups",
      "Grinder": "Built-in Burr",
      "Programmable": "24-Hour",
      "Keep Warm": "2 Hours",
    },
  },
  // Beauty & Health
  {
    id: "13",
    name: "Skincare Gift Set Premium",
    description:
      "Complete skincare routine with cleanser, toner, serum, and moisturizer.",
    price: 1999,
    originalPrice: 3499,
    image:
      "https://images.unsplash.com/photo-1556228720-195a672e8a03?w=400&h=400&fit=crop",
    category: "beauty",
    rating: 4.7,
    reviews: 2345,
    stock: 156,
    discount: 43,
    badge: "Gift Ready",
    specifications: {
      Pieces: "4",
      "Skin Type": "All Types",
      Volume: "50ml each",
      Paraben: "Free",
    },
  },
  {
    id: "14",
    name: "Electric Trimmer Professional",
    description:
      "Precision trimmer with titanium blades, waterproof design, and 90-minute runtime.",
    price: 1499,
    originalPrice: 2499,
    image:
      "https://images.unsplash.com/photo-1621607512214-68297480165e?w=400&h=400&fit=crop",
    category: "beauty",
    rating: 4.3,
    reviews: 876,
    stock: 234,
    discount: 40,
    specifications: {
      Blades: "Titanium",
      Runtime: "90 Minutes",
      Waterproof: "IPX7",
      Attachments: "6",
    },
  },
  // Sports & Fitness
  {
    id: "15",
    name: "Yoga Mat Premium 6mm",
    description:
      "Extra thick yoga mat with non-slip surface and carrying strap.",
    price: 999,
    originalPrice: 1799,
    image:
      "https://images.unsplash.com/photo-1601925260368-ae2f83cf8b7f?w=400&h=400&fit=crop",
    category: "sports",
    rating: 4.5,
    reviews: 1654,
    stock: 289,
    discount: 44,
    specifications: {
      Thickness: "6mm",
      Material: "TPE Eco-Friendly",
      Size: '183cm x 61cm',
      Weight: "1.2kg",
    },
  },
  {
    id: "16",
    name: "Adjustable Dumbbell Set 20kg",
    description:
      "Space-saving adjustable dumbbells, quick weight change system.",
    price: 5999,
    originalPrice: 8999,
    image:
      "https://images.unsplash.com/photo-1534438327276-14e5300c3a48?w=400&h=400&fit=crop",
    category: "sports",
    rating: 4.6,
    reviews: 432,
    stock: 56,
    discount: 33,
    badge: "Home Gym Essential",
    specifications: {
      "Weight Range": "2.5-20kg",
      Material: "Cast Iron + Rubber",
      "Adjustment": "Quick Lock",
      Pieces: "2",
    },
  },
  // Books
  {
    id: "17",
    name: "The Art of Programming",
    description:
      "Comprehensive guide to modern programming concepts and best practices.",
    price: 599,
    originalPrice: 999,
    image:
      "https://images.unsplash.com/photo-1544947950-fa07a98d237f?w=400&h=400&fit=crop",
    category: "books",
    rating: 4.8,
    reviews: 3421,
    stock: 500,
    discount: 40,
    badge: "Bestseller",
    specifications: {
      Pages: "450",
      Format: "Paperback",
      Language: "English",
      Author: "Tech Masters",
    },
  },
  {
    id: "18",
    name: "Business Strategy Masterclass",
    description:
      "Learn proven business strategies from world-class entrepreneurs.",
    price: 449,
    originalPrice: 799,
    image:
      "https://images.unsplash.com/photo-1589998059171-988d887df646?w=400&h=400&fit=crop",
    category: "books",
    rating: 4.4,
    reviews: 1876,
    stock: 345,
    discount: 44,
    specifications: {
      Pages: "320",
      Format: "Hardcover",
      Language: "English",
      Edition: "2024",
    },
  },
  // Toys & Games
  {
    id: "19",
    name: "Building Blocks Set 1000pcs",
    description:
      "Creative building blocks compatible with major brands, STEM learning toy.",
    price: 1299,
    originalPrice: 2499,
    image:
      "https://images.unsplash.com/photo-1587654780291-39c9404d746b?w=400&h=400&fit=crop",
    category: "toys",
    rating: 4.7,
    reviews: 2134,
    stock: 167,
    discount: 48,
    badge: "Kids Favorite",
    specifications: {
      Pieces: "1000",
      Age: "6+",
      Material: "ABS Plastic",
      Compatible: "Major Brands",
    },
  },
  {
    id: "20",
    name: "Remote Control Racing Car",
    description:
      "High-speed RC car with 4WD, rechargeable battery, and LED lights.",
    price: 1799,
    originalPrice: 2999,
    image:
      "https://images.unsplash.com/photo-1594787318286-3d835c1d207f?w=400&h=400&fit=crop",
    category: "toys",
    rating: 4.3,
    reviews: 765,
    stock: 98,
    discount: 40,
    specifications: {
      Speed: "25 km/h",
      "Battery": "Rechargeable Li-ion",
      Range: "80m",
      "Run Time": "30 min",
    },
  },
  // Grocery
  {
    id: "21",
    name: "Organic Honey 500g",
    description:
      "Pure organic honey sourced from natural bee farms, raw and unprocessed.",
    price: 349,
    originalPrice: 499,
    image:
      "https://images.unsplash.com/photo-1587049352846-4a222e784d38?w=400&h=400&fit=crop",
    category: "grocery",
    rating: 4.6,
    reviews: 1234,
    stock: 456,
    discount: 30,
    specifications: {
      Weight: "500g",
      Type: "Raw Organic",
      Origin: "Mountain Farms",
      Packaging: "Glass Jar",
    },
  },
  {
    id: "22",
    name: "Premium Basmati Rice 5kg",
    description:
      "Aged basmati rice with long grains and aromatic flavor.",
    price: 599,
    originalPrice: 799,
    image:
      "https://images.unsplash.com/photo-1586201375761-83865001e31c?w=400&h=400&fit=crop",
    category: "grocery",
    rating: 4.5,
    reviews: 2341,
    stock: 678,
    discount: 25,
    specifications: {
      Weight: "5kg",
      Type: "Aged Basmati",
      Grain: "Extra Long",
      Origin: "Punjab",
    },
  },
  {
    id: "23",
    name: "Smart Watch Fitness Pro",
    description:
      "Advanced fitness tracker with heart rate monitor, GPS, and 7-day battery life.",
    price: 4999,
    originalPrice: 7999,
    image:
      "https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=400&h=400&fit=crop",
    category: "electronics",
    rating: 4.5,
    reviews: 1892,
    stock: 145,
    discount: 38,
    badge: "Fitness Pick",
    specifications: {
      Display: '1.4" AMOLED',
      Battery: "7 Days",
      "Water Resistant": "5ATM",
      Sensors: "HR, SpO2, GPS",
    },
  },
  {
    id: "24",
    name: "Portable Power Bank 20000mAh",
    description:
      "Fast charging power bank with dual USB ports and LED display.",
    price: 1299,
    originalPrice: 1999,
    image:
      "https://images.unsplash.com/photo-1609091839311-d5365f9ff1c5?w=400&h=400&fit=crop",
    category: "electronics",
    rating: 4.4,
    reviews: 3456,
    stock: 567,
    discount: 35,
    specifications: {
      Capacity: "20000mAh",
      Output: "18W Fast Charge",
      Ports: "2 USB + Type-C",
      Weight: "350g",
    },
  },
];

export function getProductById(id: string): Product | undefined {
  return products.find((p) => p.id === id);
}

export function getProductsByCategory(category: string): Product[] {
  return products.filter((p) => p.category === category);
}

export function getDeals(): Product[] {
  return products.filter((p) => p.discount && p.discount >= 40);
}

export function getTopRated(): Product[] {
  return products.filter((p) => p.rating >= 4.5).slice(0, 8);
}

export function getNewArrivals(): Product[] {
  return products.filter((p) => p.badge === "New Arrival").slice(0, 8);
}

export function searchProducts(query: string): Product[] {
  const lowerQuery = query.toLowerCase();
  return products.filter(
    (p) =>
      p.name.toLowerCase().includes(lowerQuery) ||
      p.description.toLowerCase().includes(lowerQuery) ||
      p.category.toLowerCase().includes(lowerQuery)
  );
}
